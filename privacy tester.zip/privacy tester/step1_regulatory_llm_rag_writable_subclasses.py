"""LLM + BM25 regulatory alignment with optional verified RDF writes.

Dry run by default. --apply writes requirement individuals; approved subclass
proposals can additionally be written with --approved-subclasses JSON.
The source ontology is never overwritten.
"""

import argparse
import json
import os
import re
from pathlib import Path

from rdflib import Graph, URIRef, Literal, RDF, RDFS, OWL
from collections import Counter
import math
import hashlib
import tempfile
from rdflib import Namespace
from rdflib.namespace import XSD, DCTERMS


# ---------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------
CONFIG_PATH = "config.json"
HAS_LAW_PRED = URIRef("http://www.w3.org/2000/01/rdf-schema#hasLaw")

# Seed ontology entities — same list used by semantic_policy_extractor.py.
# When a candidate class name from the PDF is semantically close to one
# of these, we treat it as a MATCH (annotate), otherwise we create a NEW class.
SEED_ENTITIES = [
    "IoT Device", "Manufacturer", "Federal Agency", "Cybersecurity Standard",
    "Personal Information", "Service Provider", "Customer", "Website",
    "Privacy Policy", "Data Breach", "Children", "Email", "Transaction",
    "Cookie", "User", "Data Processor", "Data Collector", "Law",
    "Policy", "Affiliate", "Subsidiary", "Division", "Franchisee",
    "Stakeholder", "Regulatory Body", "Security Feature", "Network Interface",
]


# ---------------------------------------------------------------
# STEP 1a: Read the PDF text
# ---------------------------------------------------------------
def read_pdf_text(pdf_path: str) -> str:
    """Extract raw text from the uploaded regulation PDF."""
    try:
        from pypdf import PdfReader
    except ImportError:
        from PyPDF2 import PdfReader
    reader = PdfReader(pdf_path)
    chunks = []
    for page in reader.pages:
        t = page.extract_text() or ""
        if t.strip():
            chunks.append(t)
    return "\n\n".join(chunks)


# ---------------------------------------------------------------
# Legacy candidate entity extraction (not used by the agentic pipeline)
# ---------------------------------------------------------------
def extract_candidate_classes(text, model=None, top_n=15):
    """Compatibility helper: rule-based named-phrase extraction, no SBERT."""
    phrases = Counter(re.findall(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3}\b", text))
    return [], [{"label": phrase, "example_sentences": []}
                for phrase, n in phrases.most_common() if n >= 2][:top_n]


# ---------------------------------------------------------------
# STEP 1c: Apply to the knowledge graph
# ---------------------------------------------------------------
def slug(label: str) -> str:
    return re.sub(r"\W+", "_", label.strip())


def find_existing_class(g: Graph, label: str):
    """
    Return the IRI of an existing owl:Class whose rdfs:label OR local
    name matches `label` (case-insensitive). Otherwise None.
    """
    target = label.lower().strip()
    for c in g.subjects(RDF.type, OWL.Class):
        if not isinstance(c, URIRef):
            continue
        # Check labels
        for lbl in g.objects(c, RDFS.label):
            if str(lbl).lower().strip() == target:
                return c
        # Check local name
        local = str(c).rsplit("#", 1)[-1].rsplit("/", 1)[-1]
        local_clean = re.sub(r"([a-z])([A-Z])", r"\1 \2", local).replace("_", " ").lower().strip()
        if local_clean == target:
            return c
    return None


def annotate_existing_class(g: Graph, class_iri: URIRef, law_label: str, snippets: list):
    """
    Class already exists → just attach a hasLaw literal that mentions
    the new law and a couple of example sentences. This is the
    'annotate' path from the requirements.
    """
    text = f"{law_label}. " + " ".join(snippets[:2])
    g.add((class_iri, HAS_LAW_PRED, Literal(text)))


def create_new_class(g: Graph, base_iri: str, label: str, law_label: str, snippets: list):
    """
    Class doesn't exist → create a new owl:Class with label, comment,
    and a hasLaw annotation pointing at the new regulation.
    This is the 'encode into the KG through triples' path.
    """
    new_iri = URIRef(base_iri + slug(label))
    g.add((new_iri, RDF.type, OWL.Class))
    g.add((new_iri, RDFS.label, Literal(label)))
    if snippets:
        g.add((new_iri, RDFS.comment, Literal(snippets[0])))
    text = f"{law_label}. " + " ".join(snippets[:2])
    g.add((new_iri, HAS_LAW_PRED, Literal(text)))
    return new_iri


# ---------------------------------------------------------------
# STEP 1d: Register the new law in config.json so the rest of the
# app knows about it (dropdowns, coverage, etc.)
# ---------------------------------------------------------------
def register_law_in_config(config_path: str, law_id: str, law_label: str, keywords: list):
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    existing_ids = {law["id"] for law in cfg.get("laws", [])}
    if law_id in existing_ids:
        print(f"[config] Law {law_id} already registered — skipping.")
        return

    cfg.setdefault("laws", []).append({
        "id": law_id,
        "label": law_label,
        "keywords": keywords,
    })

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    print(f"[config] Registered new law: {law_label} ({law_id})")



# ---------------------------------------------------------------
# READ-ONLY REQUIREMENT -> EXISTING KG CLASS RECOMMENDATIONS
# ---------------------------------------------------------------
NON_OPERATIVE_PATTERNS = (
    re.compile(r"\bdeclares\s+that\b", re.I),
    re.compile(r"\b(?:general assembly|legislature)\s+finds\b", re.I),
    re.compile(r"\blegislative\s+(?:findings|declaration)\b", re.I),
    re.compile(r"\bpurpose\s+of\s+this\s+(?:act|part)\b", re.I),
)


def is_non_operative_declaration(text):
    """Conservative screen for clearly identified legislative findings/purpose."""
    return any(pattern.search(text) for pattern in NON_OPERATIVE_PATTERNS)


def requirement_sentences(text):
    """Heuristic candidate extraction, not a complete legal parser."""
    normalized = " ".join(text.split())
    parts = re.split(r"(?<=[.;])\s+(?=[A-Z(0-9])", normalized)
    cues = re.compile(
        r"\b(must|shall|should|is required to|are required to|"
        r"may not|shall not|must not|prohibited|require(?:s|d)?|"
        r"notify|disclose|provide|obtain consent|implement|maintain)\b",
        re.I,
    )
    seen = set()
    for part in parts:
        part = part.strip()
        if 35 <= len(part) <= 1800 and cues.search(part) and not is_non_operative_declaration(part):
            key = re.sub(r"\W+", "", part).lower()
            if key not in seen:
                seen.add(key)
                yield part



# ---------------------------------------------------------------
# STEP 2: LLM extraction of operative obligations (single chosen method)
# ---------------------------------------------------------------
def legal_chunks(text, max_chars=4200):
    """Split long laws into bounded chunks; no excerpt is silently dropped."""
    normalized = re.sub(r"\s+", " ", text).strip()
    if not normalized:
        return []
    result = []
    while normalized:
        if len(normalized) <= max_chars:
            result.append(normalized)
            break
        cut = normalized.rfind(" ", int(max_chars * 0.75), max_chars + 1)
        if cut < 0:
            cut = max_chars
        result.append(normalized[:cut].strip())
        normalized = normalized[cut:].strip()
    return result


def _parse_llm_json(content):
    """Parse a JSON response, including JSON surrounded by explanatory text."""
    content = (content or "").strip()
    if not content:
        raise ValueError("Model returned empty content (possibly exhausted output tokens)")
    if content.startswith("```"):
        content = re.sub(r"^```(?:json)?\s*", "", content, flags=re.I)
        content = re.sub(r"\s*```$", "", content).strip()
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        decoder = json.JSONDecoder()
        for pos, char in enumerate(content):
            if char == "{":
                try:
                    result, _ = decoder.raw_decode(content[pos:])
                    return result
                except json.JSONDecodeError:
                    continue
        raise ValueError("Model response did not contain a complete JSON object")


def _response_text(response):
    choice = response.choices[0]
    message = choice.message
    content = message.content or ""
    finish = getattr(choice, "finish_reason", None)
    if finish == "length":
        raise ValueError("Model hit output token limit before completing JSON")
    if not content.strip():
        raise ValueError(f"Model returned empty text (finish_reason={finish})")
    return content


def _extract_one_chunk(client, model_name, chunk, depth=0, max_depth=3):
    """Retry formatting failures; split difficult chunks without losing coverage."""
    from groq import BadRequestError
    system = (
        "Extract only operative legal obligations and prohibitions from the user text. "
        "Exclude definitions, findings, and legislative purpose. "
        "Return one compact JSON object with key requirements containing an array of "
        "verbatim substrings copied from the user text. No markdown. "
        "Do not paraphrase. Return {\"requirements\":[]} if none. "
        "Each quote must include enough context to retain its legal meaning. "
        "Never fabricate quotes."
    )
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": chunk}]
    last_error = None
    # Format controls can fail on some Groq models. Try plain JSON instruction
    # too, and repair via a second prompt when necessary.
    for attempt in range(3):
        try:
            if attempt == 0:
                response = client.chat.completions.create(
                    model=model_name, messages=messages, temperature=0,
                    response_format={"type": "json_object"}, max_tokens=2500)
            elif attempt == 1:
                response = client.chat.completions.create(
                    model=model_name, messages=messages, temperature=0,
                    max_tokens=2500)
            else:
                repair_messages = messages + [{"role": "user", "content": (
                    "Your previous answer could not be parsed. Respond with ONLY one "
                    "valid, complete, compact JSON object: "
                    "{\"requirements\":[\"exact quote\"]}. "
                    "Use [] if no operative requirements. No explanation or markdown.") }]
                response = client.chat.completions.create(
                    model=model_name, messages=repair_messages, temperature=0,
                    max_tokens=2500)
            obj = _parse_llm_json(_response_text(response))
            if not isinstance(obj, dict) or not isinstance(obj.get("requirements"), list):
                raise ValueError("Expected JSON object with requirements array")
            if any(not isinstance(q, str) for q in obj["requirements"]):
                raise ValueError("Requirements must all be strings")
            return obj["requirements"]
        except (BadRequestError, ValueError, json.JSONDecodeError) as exc:
            last_error = exc
            print(f"  [FORMAT RETRY {attempt+1}/3] {type(exc).__name__}: {str(exc)[:220]}", flush=True)
    if depth < max_depth and len(chunk) > 900:
        # Splitting reduces generation size and makes exact quote checks easier.
        mid = len(chunk) // 2
        split = chunk.rfind(" ", int(mid * 0.65), mid + 1)
        if split < 0:
            split = mid
        left, right = chunk[:split].strip(), chunk[split:].strip()
        if left and right:
            print(f"  [SPLIT] Retry as two smaller spans (depth {depth+1})", flush=True)
            return (_extract_one_chunk(client, model_name, left, depth+1, max_depth)
                    + _extract_one_chunk(client, model_name, right, depth+1, max_depth))
    raise RuntimeError(f"Unable to extract chunk after retries: {last_error}")


def extract_legal_requirements_llm(client, model_name, text, max_chunks=0):
    """Extract legal spans, verify against source, fail closed on incomplete chunks."""
    chunks = legal_chunks(text, max_chars=2600)
    if max_chunks:
        chunks = chunks[:max_chunks]
    print(f"[2] LLM legal extraction: {len(chunks)} text chunks", flush=True)
    extracted, seen, failures = [], set(), []
    for i, chunk in enumerate(chunks, 1):
        print(f"[EXTRACTION] chunk {i}/{len(chunks)}", flush=True)
        try:
            quotes = _extract_one_chunk(client, model_name, chunk)
            accepted = 0
            for quote in quotes:
                quote = re.sub(r"\s+", " ", quote).strip()
                if len(quote) < 30 or quote not in chunk:
                    print("  [REJECTED] Non-verbatim or short quote", flush=True)
                    continue
                key = re.sub(r"\W+", "", quote).lower()
                if key not in seen:
                    seen.add(key)
                    extracted.append(quote)
                    accepted += 1
            print(f"  [OK] {accepted} new verified quotes", flush=True)
        except Exception as exc:
            failures.append((i, f"{type(exc).__name__}: {exc}"))
            print(f"  [EXTRACTION ERROR] {failures[-1][1]}", flush=True)
    if failures:
        raise RuntimeError(
            f"LLM extraction failed on {len(failures)}/{len(chunks)} chunks; "
            "classification halted to prevent an incomplete result. "
            f"First failure: chunk {failures[0][0]}: {failures[0][1]}")
    print(f"[2] Extracted {len(extracted)} verified operative passages", flush=True)
    return extracted

def ontology_class_catalog(graph):
    catalog = []
    for iri in set(graph.subjects(RDF.type, OWL.Class)):
        if not isinstance(iri, URIRef):
            continue
        if (iri, OWL.deprecated, Literal(True)) in graph:
            continue
        labels = [str(x) for x in graph.objects(iri, RDFS.label)]
        local = str(iri).rsplit("#", 1)[-1].rsplit("/", 1)[-1]
        label = labels[0] if labels else re.sub(r"([a-z])([A-Z])", r"\1 \2", local).replace("_", " ")
        comments = [str(x) for x in graph.objects(iri, RDFS.comment)]
        laws = [str(x) for x in graph.objects(iri, HAS_LAW_PRED)]
        # Use actual KG descriptions rather than hardcoded seed entities.
        description = " ".join([label] * 3 + comments[:2] + laws[:3])[:3500]
        catalog.append((label, str(iri), description))
    return sorted(catalog)


# ---------------------------------------------------------------
# STEP 4: Lightweight NLP retrieval (BM25; no SBERT or LLM tokens)
# ---------------------------------------------------------------
# Normalize legal synonyms for retrieval only. The LLM sees the original
# requirement and the original KG labels/IRIs.
RETRIEVAL_SYNONYMS = {
    "disclosure": "share", "disclose": "share", "disclosed": "share",
    "discloses": "share", "sharing": "share", "shared": "share",
    "thirdparty": "thirdparty", "consumer": "customer", "consumers": "customer",
    "personal": "personal", "information": "data", "records": "data",
    "processing": "process", "processed": "process", "collection": "collect",
    "collected": "collect", "retention": "retain", "deletion": "delete",
    "security": "secure", "protection": "protect", "privacy": "privacy",
}
RETRIEVAL_STOPWORDS = {
    "the", "and", "or", "a", "an", "of", "for", "to", "in", "on", "by",
    "with", "from", "as", "is", "are", "be", "that", "this", "which",
    "such", "its", "their", "under", "section", "part", "page", "shall",
    "must", "may", "can", "will", "any", "each", "other", "not", "it",
}


def retrieval_tokens(text):
    """Simple legal-aware lexical normalization for class retrieval."""
    text = re.sub(r"third[ -]part(?:y|ies)", " thirdparty ", text.lower())
    tokens = re.findall(r"[a-z][a-z0-9]*", text)
    return [RETRIEVAL_SYNONYMS.get(t, t) for t in tokens
            if t not in RETRIEVAL_STOPWORDS and len(t) > 1]


class BM25ClassRetriever:
    """Indexes the current KG class catalog; scores by term relevance."""

    def __init__(self, catalog):
        self.catalog = catalog
        self.docs = [retrieval_tokens(desc) for _, _, desc in catalog]
        self.lengths = [len(doc) for doc in self.docs]
        self.avg_length = sum(self.lengths) / max(1, len(self.docs))
        self.tf = [Counter(doc) for doc in self.docs]
        df = Counter()
        for doc in self.docs:
            df.update(set(doc))
        n = len(self.docs)
        self.idf = {term: math.log(1 + (n - freq + 0.5) / (freq + 0.5))
                    for term, freq in df.items()}

    def search(self, requirement, top_k=5):
        query = set(retrieval_tokens(requirement))
        scored = []
        for i, (label, iri, description) in enumerate(self.catalog):
            score = 0.0
            for term in query:
                freq = self.tf[i].get(term, 0)
                if freq:
                    denom = freq + 1.5 * (0.25 + 0.75 * self.lengths[i] / max(1, self.avg_length))
                    score += self.idf.get(term, 0) * (freq * 2.5) / denom
            # Labels are more reliable than law annotations for class identity.
            label_terms = set(retrieval_tokens(label))
            score += 1.25 * sum(self.idf.get(t, 0) for t in query & label_terms)
            scored.append((score, label, iri, description))
        scored.sort(key=lambda x: (-x[0], x[1], x[2]))
        return [(label, iri, description, score)
                for score, label, iri, description in scored[:top_k]]


def agent_decide(client, model_name, requirement, candidates, domains):
    """LLM makes a grounded proposal; deterministic checks gate its output."""
    import json
    options = [
        {"label": label, "iri": iri, "retrieval_score": round(score, 3),
         "description": description[:650]}
        for label, iri, description, score in candidates
    ]
    system = (
        "You are a regulatory-control ontology alignment agent. "
        "Classify the underlying regulatory CONTROL, not the legal actor, law title, "
        "deadline, or a random capitalized phrase. "
        "Return ONLY a JSON object with fields: action, domain, selected_iri, "
        "proposed_class_label, proposed_parent_iri, rationale. "
        "action must be exactly one of REUSE_EXISTING_CLASS, CREATE_SUBCLASS, "
        "CREATE_NEW_CONTROL, NEEDS_HUMAN_REVIEW. "
        "For reuse, selected_iri MUST be one of the supplied candidate IRIs. "
        "For subclass, proposed_parent_iri MUST be one of the supplied candidate IRIs. "
        "For new control, propose a reusable control name, not a statutory provision. "
        "Use NEEDS_HUMAN_REVIEW when evidence is insufficient. "
        "REUSE-FIRST POLICY: If an existing class can represent the underlying concept, "
        "choose REUSE_EXISTING_CLASS even if the provision adds conditions, obligations, "
        "actors, jurisdictions, deadlines, or different wording. "
        "Do not invent a subclass merely because the wording is more specific. "
        "CREATE_SUBCLASS only for a genuinely distinct, reusable kind of control that "
        "is logically a subtype of a retrieved existing CONTROL class; explain the "
        "distinct mechanism and the valid is-a relationship in rationale. "
        "CREATE_NEW_CONTROL only if no retrieved class adequately represents the concept. "
        "PRESERVE THE EXISTING ONTOLOGY: new legal wording, jurisdiction, actor, "
        "condition, disclosure scenario, or specific obligation is normally a new "
        "REQUIREMENT INSTANCE associated with an existing class, NOT a new OWL class. "
        "Choose the broadest existing class that accurately covers the topic, even "
        "when it is not a perfect phrase match. Existing classes are intentionally "
        "reusable across laws. A new class is an exceptional last resort. "
        "Never propose a class just to represent one statutory clause. "
        "If considering CREATE_SUBCLASS or CREATE_NEW_CONTROL, explain why "
        "linking the requirement to an existing class would lose a distinct, "
        "reusable control concept; otherwise choose REUSE_EXISTING_CLASS. "
        "Personal Information is a data concept, not automatically a parent for "
        "organizational roles such as Responsible Data Custodian. "
        "For consumer-directed disclosure of personal data or customer records to third parties, "
        "prefer REUSE_EXISTING_CLASS with the existing Data Sharing Practice class when supplied. "
        "Do not invent Consumer-Directed Disclosure of Personal Data as a new class solely "
        "because the provision describes a particular disclosure scenario. "
        "For personal-data handling passages that introduce no distinct control, "
        "prefer reusing the existing Personal Information class if supplied. "
        "Legislative findings, declarations, and purpose statements are context, not "
        "automatically enforceable obligations; if presented, avoid proposing new classes. "
        "For reuse, set proposed_class_label and proposed_parent_iri to empty strings. "
        "Never claim a class exists unless its IRI appears in candidates. "
        "Do not create or update any graph."
    )
    user = json.dumps({
        "requirement": requirement,
        "domains": domains,
        "existing_kg_candidates": options,
    }, ensure_ascii=False)
    # Strict structured outputs are preferable to Groq JSON object mode.
    fields = ["action", "domain", "selected_iri", "proposed_class_label",
              "proposed_parent_iri", "rationale"]
    schema = {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": [
                "REUSE_EXISTING_CLASS", "CREATE_SUBCLASS",
                "CREATE_NEW_CONTROL", "NEEDS_HUMAN_REVIEW", "AGENT_ERROR"]},
            "domain": {"type": "string", "enum": domains},
            "selected_iri": {"type": "string"},
            "proposed_class_label": {"type": "string"},
            "proposed_parent_iri": {"type": "string"},
            "rationale": {"type": "string"},
        },
        "required": fields,
        "additionalProperties": False,
    }
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": user}]
    import logging
    from groq import BadRequestError
    try:
        response = client.chat.completions.create(
            model=model_name, messages=messages,
            response_format={"type": "json_schema", "json_schema": {
                "name": "ontology_alignment", "strict": True, "schema": schema}},
            temperature=0, max_tokens=1100,
        )
    except BadRequestError as exc:
        if "json_validate_failed" not in str(exc) and "Failed to validate JSON" not in str(exc):
            raise
        logging.warning("Structured output failed; retrying once without forced JSON mode")
        response = client.chat.completions.create(
            model=model_name, messages=messages, temperature=0,
            max_tokens=1100,
        )
    content = (response.choices[0].message.content or "").strip()
    if content.startswith("```"):
        content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    try:
        result = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError("Agent response is not valid JSON") from exc
    if not isinstance(result, dict):
        raise ValueError("Agent response is not a JSON object")
    allowed = {"REUSE_EXISTING_CLASS", "CREATE_SUBCLASS",
               "CREATE_NEW_CONTROL", "NEEDS_HUMAN_REVIEW"}
    valid_iris = {x["iri"] for x in options}
    action = result.get("action")
    if action not in allowed:
        raise ValueError("Agent returned invalid action")
    if action == "REUSE_EXISTING_CLASS" and result.get("selected_iri") not in valid_iris:
        raise ValueError("Agent selected a class outside retrieved KG candidates")
    if action == "CREATE_SUBCLASS" and result.get("proposed_parent_iri") not in valid_iris:
        raise ValueError("Agent proposed a parent outside retrieved KG candidates")
    if action in {"CREATE_SUBCLASS", "CREATE_NEW_CONTROL"}:
        label = str(result.get("proposed_class_label") or "").strip()
        if not label or len(label) > 100:
            raise ValueError("Agent did not provide a valid proposed class label")
    if result.get("domain") not in domains:
        raise ValueError("Agent returned unknown topic domain")
    if not str(result.get("rationale") or "").strip():
        raise ValueError("Agent omitted rationale")
    return result


def apply_reuse_policy(decision, candidates):
    """Block one known false subclass pattern without banning valid subclasses."""
    personal_iri = "http://yourdomain.org/ontology/laws#Personal_Information"
    available = {iri for _, iri, _, _ in candidates}
    label = str(decision.get("proposed_class_label") or "").strip().lower()
    # A custodian is an organizational role, not a subclass of information.
    # In this specific case, prefer thematic reuse rather than minting a class.
    if (decision.get("action") == "CREATE_SUBCLASS"
            and decision.get("proposed_parent_iri") == personal_iri
            and personal_iri in available
            and label in {"responsible data custodian", "responsible data custodians", "data custodian"}):
        decision = dict(decision)
        decision.update({
            "action": "REUSE_EXISTING_CLASS",
            "selected_iri": personal_iri,
            "proposed_class_label": "",
            "proposed_parent_iri": "",
            "rationale": "Reused Personal Information: a data custodian is not an is-a subtype of personal information; no distinct control class is justified by this passage.",
        })
    return decision


def apply_data_sharing_practice_policy(decision, requirement, candidates):
    """Reuse Data Sharing Practice for narrowly defined consumer-directed data disclosure.

    This is an ontology-alignment policy, not a claim that the passage is an
    enforceable requirement. It does not mutate the RDF graph.
    """
    sharing_iri = "http://yourdomain.org/ontology/laws#Data_Sharing_Practice"
    available = {iri for _, iri, _, _ in candidates}
    if sharing_iri not in available:
        return decision
    if decision.get("action") == "AGENT_ERROR":
        return decision

    normalized = re.sub(r"\s+", " ", requirement).lower()
    personal_data = bool(re.search(r"\b(personal data|personal information|customer records)\b", normalized))
    disclosure = bool(re.search(r"\b(disclos(?:e|es|ed|ure)|shar(?:e|es|ing))\b", normalized))
    consumer_directed = bool(re.search(
        r"\b(consumer directs?|consumer-directed|consumer authoriz(?:es|ed)|"
        r"at the (consumer'?s|individual'?s) direction|"
        r"consumer intentionally discloses)\b", normalized
    ))
    third_party = bool(re.search(r"\bthird[ -]part(?:y|ies)\b", normalized))

    if personal_data and disclosure and consumer_directed and third_party:
        updated = dict(decision)
        updated.update({
            "action": "REUSE_EXISTING_CLASS",
            "domain": "Data Sharing and Third-Party Disclosure",
            "selected_iri": sharing_iri,
            "proposed_class_label": "",
            "proposed_parent_iri": "",
            "rationale": (
                "Ontology reuse policy: consumer-directed disclosure of personal data "
                "to a third party is mapped to the existing Data Sharing Practice class. "
                "The specific disclosure condition does not itself justify a new OWL class. "
                "This is a thematic mapping, not a determination that the passage "
                "imposes an enforceable obligation."
            ),
        })
        return updated
    return decision


def preserve_existing_classes(client, model_name, requirement, decision, retriever, domains,
                              catalog, review_top_k=20):
    """Second-pass KG reuse check before accepting any ontology expansion proposal.

    A new class is not automatically accepted just because it was not in the
    initial shortlist. Review a wider selection of *actual* ontology classes.
    Fail closed to human review on API/validation errors, not a fabricated reuse.
    """
    if decision.get("action") not in {"CREATE_SUBCLASS", "CREATE_NEW_CONTROL"}:
        return decision
    expanded = retriever.search(requirement, top_k=min(review_top_k, len(catalog)))
    existing = {iri for _, iri, _, _ in expanded}
    # Preserve the initial selected parent when it is a genuine existing class.
    parent = decision.get("proposed_parent_iri")
    if parent and parent not in existing:
        expanded.extend(x for x in catalog_as_candidates(catalog) if x[1] == parent)
    print(f"[CLASS PRESERVATION] Rechecking {len(expanded)} existing KG classes before proposing expansion", flush=True)
    try:
        reviewed = agent_decide(client, model_name, requirement, expanded, domains)
    except Exception as exc:
        updated = dict(decision)
        updated.update({
            "action": "NEEDS_HUMAN_REVIEW", "selected_iri": "",
            "proposed_class_label": "", "proposed_parent_iri": "",
            "rationale": (
                "New-class proposal was withheld to preserve the existing KG: "
                f"second-pass validation failed ({type(exc).__name__}). "
                "No class creation is recommended without review."
            ),
        })
        return updated
    if reviewed["action"] == "REUSE_EXISTING_CLASS":
        reviewed["rationale"] = (
            "Class preservation review: " + reviewed["rationale"]
        )
        return reviewed
    # Two independent model calls can repeat the same bias. Require a person to
    # verify genuine novelty before accepting any proposed ontology extension.
    updated = dict(decision)
    updated.update({
        "action": "NEEDS_HUMAN_REVIEW", "selected_iri": "",
        "rationale": (
            "POTENTIAL ONTOLOGY EXTENSION — not approved. Initial agent proposed "
            f"{decision['action']} ({decision.get('proposed_class_label') or 'unnamed'}). "
            "A broader KG reuse check did not identify a confident existing-class "
            "mapping. A reviewer should verify novelty and correct OWL parentage "
            "before any new class is added. "
            f"Initial reasoning: {decision.get('rationale', '')}"
        ),
    })
    return updated


def catalog_as_candidates(catalog):
    return [(label, iri, description, 0.0) for label, iri, description in catalog]


# ---------------------------------------------------------------
# APPEND-ONLY REGULATORY REQUIREMENT INDIVIDUALS
# ---------------------------------------------------------------
REQ = Namespace("http://yourdomain.org/ontology/regulatory-requirements#")

def add_requirement_individual(graph, pdf, law_label, passage, decision, source_sha256):
    """Add an idempotent requirement individual; never change OWL class triples."""
    if decision.get("action") != "REUSE_EXISTING_CLASS":
        return "skipped", None
    class_iri = URIRef(decision.get("selected_iri", ""))
    if (class_iri, RDF.type, OWL.Class) not in graph:
        raise ValueError(f"Agent selected an IRI that is not an existing OWL class: {class_iri}")
    fingerprint = hashlib.sha256((source_sha256 + "\n" + passage).encode("utf-8")).hexdigest()
    req_iri = REQ["requirement_" + fingerprint]
    if (req_iri, RDF.type, REQ.RegulatoryRequirement) in graph:
        return "already_exists", req_iri
    graph.add((req_iri, RDF.type, REQ.RegulatoryRequirement))
    graph.add((req_iri, REQ.classifiedUnderControl, class_iri))
    graph.add((req_iri, REQ.requirementText, Literal(passage)))
    graph.add((req_iri, REQ.topicDomain, Literal(decision["domain"])))
    graph.add((req_iri, REQ.alignmentRationale, Literal(decision["rationale"])))
    graph.add((req_iri, REQ.alignmentMethod, Literal("LLM + BM25 + reuse-first validation")))
    graph.add((req_iri, REQ.sourceDocumentSHA256, Literal(source_sha256)))
    graph.add((req_iri, DCTERMS.source, Literal(Path(pdf).name)))
    graph.add((req_iri, REQ.lawLabel, Literal(law_label)))
    return "added", req_iri


def load_approved_subclasses(path, graph):
    """Load explicitly reviewed class-label -> existing parent IRI approvals."""
    if not path:
        return {}
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("Approval JSON must map proposed class labels to parent IRIs")
    approvals = {}
    for label, parent in raw.items():
        if not isinstance(label, str) or not label.strip() or not isinstance(parent, str):
            raise ValueError("Approval entries must be nonempty class label -> parent IRI")
        parent_iri = URIRef(parent)
        if (parent_iri, RDF.type, OWL.Class) not in graph:
            raise ValueError(f"Approved parent is not an existing OWL class: {parent}")
        approvals[label.casefold().strip()] = parent_iri
    return approvals


def write_approved_subclass(graph, label, parent_iri, law_label, passage):
    """Create an OWL subclass only when parentage was explicitly approved."""
    label = re.sub(r"\s+", " ", label).strip()
    if not label or len(label) > 100:
        raise ValueError("Invalid proposed class label")
    existing = find_existing_class(graph, label)
    if existing:
        if (existing, RDFS.subClassOf, parent_iri) not in graph:
            raise ValueError(f"Existing class '{label}' has no approved parent relationship; refusing to modify it")
        return "already_exists", existing
    slug_part = re.sub(r"[^A-Za-z0-9_]+", "_", label.replace(" ", "_")).strip("_")
    if not slug_part:
        raise ValueError("Invalid subclass IRI suffix")
    base = str(parent_iri).split("#")[0] + "#" if "#" in str(parent_iri) else str(parent_iri).rsplit("/", 1)[0] + "/"
    new_iri = URIRef(base + slug_part)
    if any(graph.triples((new_iri, None, None))) and (new_iri, RDF.type, OWL.Class) not in graph:
        raise ValueError(f"IRI collision for proposed subclass: {new_iri}")
    if (new_iri, RDF.type, OWL.Class) in graph:
        raise ValueError(f"IRI collision with differently named class: {new_iri}")
    graph.add((new_iri, RDF.type, OWL.Class))
    graph.add((new_iri, RDFS.label, Literal(label)))
    graph.add((new_iri, RDFS.subClassOf, parent_iri))
    graph.add((new_iri, RDFS.comment, Literal(
        f"Reviewed regulatory control concept referenced by {law_label}. Example passage: {passage[:600]}")))
    return "added", new_iri


def save_verified_graph(graph, original_graph, source_path, output_path):
    """Atomic RDF/XML save, followed by a read-back and preservation check."""
    source_path = Path(source_path).resolve()
    output_path = Path(output_path).resolve()
    if source_path == output_path:
        raise ValueError("Refusing to overwrite source ontology; choose a different --output")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".kg_write_", suffix=".rdf", dir=str(output_path.parent))
    os.close(fd)
    try:
        graph.serialize(destination=tmp, format="xml")
        check = Graph()
        check.parse(tmp, format="xml")
        if len(check) != len(graph) or any(triple not in check for triple in original_graph):
            raise RuntimeError("RDF round-trip failed or original KG triples were lost")
        os.replace(tmp, output_path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def print_requirement_class_recommendations(pdf, ontology, threshold=0.40, top_k=5,
                                            model_name="openai/gpt-oss-20b",
                                            max_requirements=0, max_chunks=0, apply=False, output=None, law_label=None,
                                            approved_subclasses=None, review_report=None):
    import os
    import time
    from dotenv import load_dotenv
    from groq import Groq
    load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env")
    key = os.getenv("GROQ_API_KEY")
    if not key:
        raise RuntimeError("GROQ_API_KEY missing from project .env or environment")
    client = Groq(api_key=key, max_retries=3, timeout=90)
    domains = [
        "Data Collection and Minimization",
        "Data Processing and Purpose Limitation",
        "Data Sharing and Third-Party Disclosure",
        "Data Retention and Deletion",
        "Consent and Consumer Rights",
        "Transparency and Privacy Notices",
        "Security and Breach Response",
        "Governance, Risk and Regulatory Accountability",
        "Other Regulatory Topic",
    ]
    print(f"[1] Reading regulation: {pdf}", flush=True)
    text = read_pdf_text(str(pdf))
    if not text.strip():
        raise ValueError("No extractable PDF text. Scanned PDFs may need OCR.")
    requirements = extract_legal_requirements_llm(client, model_name, text, max_chunks=max_chunks)
    if max_requirements > 0:
        requirements = requirements[:max_requirements]
    print(f"[2] Processing {len(requirements)} LLM-extracted requirements", flush=True)
    print(f"[3] Loading KG: {ontology}", flush=True)
    graph = Graph()
    graph.parse(str(ontology))
    original_graph = set(graph) if apply else None
    source_sha256 = hashlib.sha256(Path(pdf).read_bytes()).hexdigest()
    law_label = law_label or Path(pdf).stem
    if apply:
        if not output:
            raise ValueError("--apply requires --output")
        if Path(output).resolve() == Path(ontology).resolve():
            raise ValueError("--output must differ from --ontology")
    approvals = load_approved_subclasses(approved_subclasses, graph)
    if approvals and not apply:
        print("[INFO] Approved subclass map loaded; dry run does not write.", flush=True)
    catalog = ontology_class_catalog(graph)
    if not catalog:
        raise ValueError("No OWL classes found.")
    print(f"[4] Building NLP BM25 index over {len(catalog)} KG classes", flush=True)
    retriever = BM25ClassRetriever(catalog)
    counts = {k: 0 for k in ["REUSE_EXISTING_CLASS", "CREATE_SUBCLASS",
                             "CREATE_NEW_CONTROL", "NEEDS_HUMAN_REVIEW", "AGENT_ERROR"]}
    write_counts = {"added": 0, "already_exists": 0, "skipped": 0}
    subclass_counts = {"added": 0, "already_exists": 0, "not_approved": 0}
    review_items = []
    for offset in range(0, len(requirements), 24):
        batch = requirements[offset:offset+24]
        for i, passage in enumerate(batch):
            number = offset+i+1
            candidates = retriever.search(passage, top_k=min(top_k, len(catalog)))
            print(f"\\n{'='*75}\\nREQUIREMENT CANDIDATE {number} | {Path(pdf).name}", flush=True)
            print(f"TEXT: {passage}", flush=True)
            print("KG CANDIDATES:", flush=True)
            for label, iri, _, score in candidates:
                print(f"  {label} | BM25={score:.3f} | {iri}", flush=True)
            try:
                decision = apply_data_sharing_practice_policy(
                    apply_reuse_policy(
                        agent_decide(client, model_name, passage, candidates, domains), candidates
                    ), passage, candidates
                )
                decision = preserve_existing_classes(
                    client, model_name, passage, decision, retriever, domains, catalog
                )
            except Exception as exc:
                # Do not fabricate a decision when the agent or API fails.
                decision = {"action": "AGENT_ERROR", "domain": "unresolved",
                            "selected_iri": "", "proposed_class_label": "",
                            "proposed_parent_iri": "",
                            "rationale": f"Agent unavailable or invalid response: {type(exc).__name__}: {exc}"}
            counts[decision["action"]] += 1
            print(f"AGENT STATUS: {decision['action']}", flush=True)
            print(f"TOPIC DOMAIN: {decision['domain']}", flush=True)
            print(f"EXISTING CLASS IRI: {decision.get('selected_iri') or '(none)'}", flush=True)
            print(f"PROPOSED CLASS: {decision.get('proposed_class_label') or '(none)'}", flush=True)
            print(f"PROPOSED PARENT: {decision.get('proposed_parent_iri') or '(none)'}", flush=True)
            print(f"REASON: {decision['rationale']}", flush=True)
            review_items.append({"passage": passage, "decision": decision, "source_pdf": str(pdf)})
            if apply and decision.get("action") == "NEEDS_HUMAN_REVIEW":
                label = str(decision.get("proposed_class_label") or "").strip()
                approved_parent = approvals.get(label.casefold()) if label else None
                if approved_parent is not None:
                    status, class_iri = write_approved_subclass(
                        graph, label, approved_parent, law_label, passage)
                    subclass_counts[status] += 1
                    print(f"KG SUBCLASS: {status.upper()} | {class_iri} | parent={approved_parent}", flush=True)
                    # Store the legal requirement as an individual, not as a class annotation.
                    decision = dict(decision, action="REUSE_EXISTING_CLASS", selected_iri=str(class_iri))
                else:
                    subclass_counts["not_approved"] += 1
            if apply:
                result, req_iri = add_requirement_individual(
                    graph, pdf, law_label, passage, decision, source_sha256)
                write_counts[result] += 1
                print(f"KG WRITE: {result.upper()} | {req_iri or '(no requirement individual)'}", flush=True)
            else:
                print("KG STATUS: DRY RUN — NO RDF CHANGES", flush=True)
            time.sleep(1.0)
    print(f"\\n{'='*75}\\nSUMMARY: {len(requirements)} candidate passages", flush=True)
    for action, count in counts.items():
        print(f"  {action}: {count}", flush=True)
    if review_report:
        Path(review_report).write_text(json.dumps(review_items, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[REVIEW REPORT] {review_report}", flush=True)
    if apply:
        save_verified_graph(graph, original_graph, ontology, output)
        print(f"[SAVED] {output} | {len(graph)} RDF triples", flush=True)
        print(f"[WRITES] {write_counts} | subclasses={subclass_counts}", flush=True)
        print("Original ontology and existing triples preserved; config.json unchanged.", flush=True)
    else:
        print("DRY RUN: No RDF file written. Pass --apply --output PATH to save.", flush=True)
    print("WARNING: LLM extraction may miss or misclassify legal provisions; human validation required.", flush=True)


def main():
    ap = argparse.ArgumentParser(description="Agentic regulatory KG alignment and optional append-only RDF writes")
    ap.add_argument("--pdf", required=True, help="Regulation PDF")
    ap.add_argument("--ontology", help="RDF/OWL path (or use config.json)")
    ap.add_argument("--config", default=CONFIG_PATH)
    ap.add_argument("--threshold", type=float, default=0.40,
                    help="Deprecated compatibility argument; BM25 uses ranking, not a threshold")
    ap.add_argument("--top-k", type=int, default=5)
    ap.add_argument("--model", default="openai/gpt-oss-20b")
    ap.add_argument("--max-chunks", type=int, default=0,
                    help="Limit LLM extraction chunks for a trial run; 0 means all")
    ap.add_argument("--max-requirements", type=int, default=0,
                    help="Limit for a trial run; 0 means all candidates")
    ap.add_argument("--apply", action="store_true", help="Write mapped requirement individuals to a NEW RDF file")
    ap.add_argument("--output", help="Output RDF/XML file; required with --apply; must differ from source")
    ap.add_argument("--law-label", help="Human-readable law name (default: PDF filename stem)")
    ap.add_argument("--approved-subclasses", help="JSON mapping reviewed proposed subclass labels to existing parent class IRIs")
    ap.add_argument("--review-report", help="Optional JSON file containing all decisions and proposed subclasses")
    args = ap.parse_args()
    if args.ontology:
        ontology = Path(args.ontology)
    else:
        config_path = Path(args.config).resolve()
        cfg = json.loads(config_path.read_text(encoding="utf-8"))
        ontology = Path(cfg["ontology_path"])
        if not ontology.is_absolute():
            ontology = config_path.parent / ontology
    print_requirement_class_recommendations(
        args.pdf, ontology, args.threshold, args.top_k,
        args.model, args.max_requirements, args.max_chunks,
        args.apply, args.output, args.law_label, args.approved_subclasses, args.review_report
    )


if __name__ == "__main__":
    main()

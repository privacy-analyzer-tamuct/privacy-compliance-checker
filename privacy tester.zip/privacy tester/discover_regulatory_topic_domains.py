#!/usr/bin/env python3
"""Corpus-wide topic-domain discovery against an existing RDF/OWL ontology.

Read-only by default. Produces an evidence-backed JSON report and optional
OWL proposal graph; never changes the source ontology.
"""
import argparse
import collections
import hashlib
import json
import re
import sys
from pathlib import Path

from rdflib import Graph, Literal, Namespace, RDF, RDFS, OWL, URIRef

STOP = set("""the and for with from that this these those shall must may not are was were have has had into upon such each every any all other under within where when which their its through between pursuant accordance including includes include means defined section sections paragraph article act law state states controller processor consumer person persons data personal information processing disclose disclosure use using require required provided provide notwithstanding pursuant subject regarding respect part chapter title page senate bill""".split())
WORDS = re.compile(r"[A-Za-z][A-Za-z-]{2,}")
OBLIGATION = re.compile(r"\b(shall|must|may not|shall not|must not|is required to|are required to|prohibited from|has the right to|have the right to)\b", re.I)
NOISE = re.compile(r"\b(the general assembly (finds|declares)|legislative (findings|declaration)|purpose of this (act|part))\b", re.I)

# These are discovery labels, NOT assumed to exist as classes in the RDF.
# Only suggest labels that have corpus evidence and are not covered by
# user-specified existing domains or similarly named KG classes.
THEMES = {
    "Consumer Rights and Consent": [
        r"\bconsent\b", r"\bopt[- ]out\b", r"\bappeal\b", r"\bright to (access|delete|correct|know)\b",
        r"\bconsumer request\b", r"\bwithdraw consent\b", r"\bdata portability\b"],
    "Transparency and Privacy Notices": [
        r"\bprivacy notice\b", r"\bprivacy policy\b", r"\bnotice to consumers\b",
        r"\bpublicly available\b", r"\btransparen\w*\b", r"\bnotice of (collection|processing)\b"],
    "Retention and Deletion": [
        r"\bretention\b", r"\bretain\b", r"\bdelete\b", r"\bdeletion\b",
        r"\berase\b", r"\bdestruction\b", r"\bdata minimization\b"],
    "Risk Assessments and Accountability": [
        r"\bdata protection assessment\b", r"\brisk assessment\b",
        r"\bimpact assessment\b", r"\bdocument\w* compliance\b",
        r"\baccountab\w*\b", r"\bprivacy impact\b"],
    "Sensitive Data and Children": [
        r"\bsensitive (personal )?data\b", r"\bbiometric\b", r"\bgenetic\b",
        r"\bchild(?:ren)?\b", r"\bminor(?:s)?\b", r"\bprecise geolocation\b"],
    "Breach Notification and Incident Response": [
        r"\bdata breach\b", r"\bsecurity incident\b", r"\bbreach notification\b",
        r"\bnotify.{0,45}breach\b", r"\bincident response\b"],
    "Automated Decisions and Profiling": [
        r"\bprofiling\b", r"\bautomated decision\w*\b", r"\btargeted advertising\b",
        r"\balgorithmic\b", r"\bautomated processing\b"],
    "Third-Party Contracts and Vendor Oversight": [
        r"\bprocessor contract\b", r"\bcontractual obligation\b",
        r"\bthird.party agreement\b", r"\bsubprocessor\b",
        r"\bprocessor shall\b", r"\bcontroller.processor\b"],
    "Enforcement and Regulatory Reporting": [
        r"\battorney general\b", r"\bcivil penalty\b", r"\benforcement\b",
        r"\bregulatory authority\b", r"\breport to\b", r"\bcure period\b"],
}
THEME_RE = {k: [re.compile(p, re.I) for p in pats] for k,pats in THEMES.items()}


def extract_pdf(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError as exc:
            raise RuntimeError("Install a PDF reader: py -m pip install pypdf") from exc
    reader = PdfReader(str(path))
    pages = [(i+1, page.extract_text() or "") for i,page in enumerate(reader.pages)]
    if not any(t.strip() for _,t in pages):
        raise ValueError("No extractable text (scanned PDFs need OCR).")
    return pages


def passages_from_page(text):
    # Split at punctuation and line breaks, retaining a bounded context window.
    text = re.sub(r"(?m)^\s*(?:PAGE\s+\d+[-–]?)?(?:SENATE|HOUSE)\s+BILL\s+\d+[-\d]*\s*$", " ", text, flags=re.I)
    text = re.sub(r"\s+", " ", text)
    parts = re.split(r"(?<=[.;])\s+(?=[A-Z(0-9])", text)
    # Group nearby short fragments to preserve context, but don't mix pages.
    buf = ""
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if len(buf) + len(part) < 180:
            buf = (buf + " " + part).strip()
            continue
        if buf:
            yield buf
        buf = part
        while len(buf) > 1100:
            boundary = buf.rfind(" ", 0, 1050)
            if boundary < 300:
                boundary = 1050
            yield buf[:boundary].strip()
            buf = buf[boundary:].strip()
    if buf:
        yield buf


def name_of(iri, graph):
    label = next(iter(graph.objects(iri, RDFS.label)), None)
    if label:
        return str(label)
    return re.sub(r"[_-]+", " ", str(iri).rsplit("#",1)[-1].rsplit("/",1)[-1])


def normalize(s):
    return set(x.lower() for x in WORDS.findall(s) if x.lower() not in STOP)


def class_inventory(graph):
    classes = set(graph.subjects(RDF.type, OWL.Class))
    classes.update(graph.subjects(RDFS.subClassOf, None))
    classes.update(o for o in graph.objects(None, RDFS.subClassOf) if isinstance(o, URIRef))
    return sorted([{"iri": str(c), "label": name_of(c,graph)} for c in classes],
                  key=lambda x: x["label"].lower())


def is_covered(theme, existing, catalog):
    tokens = normalize(theme)
    for label in existing:
        a = normalize(label)
        if a and (len(tokens & a)/len(a) >= .67 or len(tokens & a)/len(tokens) >= .75):
            return True, "Already covered by selected domain: "+label
    for c in catalog:
        a = normalize(c["label"])
        if a and len(a)>=2 and len(tokens & a)/len(a)>=.80 and len(tokens & a)/len(tokens)>=.60:
            return True, "Similar existing KG class: "+c["label"]
    return False, ""


def main():
    ap = argparse.ArgumentParser(description="Read-only corpus topic-domain discovery from PDF folder")
    ap.add_argument("--folder", required=True)
    ap.add_argument("--ontology", required=True)
    ap.add_argument("--existing-domains", nargs="+", default=None,
                    help="Names or IRIs of your THREE established domains; provide explicitly for accurate novelty checks")
    ap.add_argument("--max-new-domains", type=int, default=3)
    ap.add_argument("--min-documents", type=int, default=2,
                    help="Distinct PDFs needed for a suggested new domain")
    ap.add_argument("--min-passages", type=int, default=3)
    ap.add_argument("--output", default="topic_domain_discovery_report.json")
    ap.add_argument("--proposal-rdf", default=None,
                    help="Optional separate Turtle file with proposed classes (never modifies input RDF)")
    ap.add_argument("--include-nonoperative", action="store_true",
                    help="Include all passages, not just those containing obligation cues")
    args = ap.parse_args()
    folder, ontology = Path(args.folder), Path(args.ontology)
    pdfs = sorted(folder.rglob("*.pdf"))
    if not pdfs:
        ap.error("No PDFs found in folder: "+str(folder))
    graph = Graph()
    graph.parse(str(ontology))
    catalog = class_inventory(graph)
    print(f"[KG] {len(graph)} triples; {len(catalog)} classes", flush=True)
    print("[KG] Existing classes include:", ", ".join(x["label"] for x in catalog[:20]), flush=True)
    if args.existing_domains:
        selected = args.existing_domains
    else:
        # The RDF contains many classes; it does not identify three topic
        # domains explicitly. Avoid falsely claiming to know which three.
        selected = []
        print("[WARNING] No --existing-domains specified. Three established domains cannot be inferred reliably from this RDF.", flush=True)
    for d in selected:
        print(f"[EXISTING DOMAIN] {d}", flush=True)
    hits = {k: {"docs": set(), "passages": 0, "examples": [], "patterns": collections.Counter()}
            for k in THEMES}
    errors = []
    scanned = 0
    seen_global = set()
    for i,pdf in enumerate(pdfs,1):
        print(f"[PDF {i}/{len(pdfs)}] {pdf.name}", flush=True)
        try:
            pages = extract_pdf(pdf)
        except Exception as exc:
            errors.append({"file":str(pdf), "error":str(exc)})
            print(f"  [ERROR] {exc}", flush=True)
            continue
        scanned += 1
        for page,text in pages:
            for passage in passages_from_page(text):
                if not args.include_nonoperative and not OBLIGATION.search(passage):
                    continue
                if NOISE.search(passage):
                    continue
                digest = hashlib.sha256((pdf.name+passage.lower()).encode()).hexdigest()
                if digest in seen_global:
                    continue
                seen_global.add(digest)
                for theme,patterns in THEME_RE.items():
                    matched = [THEMES[theme][j] for j,pat in enumerate(patterns) if pat.search(passage)]
                    if not matched:
                        continue
                    h=hits[theme]
                    h["docs"].add(pdf.name)
                    h["passages"]+=1
                    h["patterns"].update(matched)
                    if len(h["examples"])<4:
                        h["examples"].append({"pdf":pdf.name, "page":page, "quote":passage[:650]})
    results=[]
    for theme,h in hits.items():
        covered,reason=is_covered(theme,selected,catalog)
        docs=len(h["docs"])
        eligible=docs>=args.min_documents and h["passages"]>=args.min_passages and not covered
        results.append({
            "topic_domain":theme, "distinct_pdfs":docs, "matching_passages":h["passages"],
            "already_covered":covered, "coverage_reason":reason,
            "eligible_for_proposal":eligible,
            "evidence":h["examples"],
            "matched_patterns":dict(h["patterns"].most_common(8)),
        })
    results.sort(key=lambda r:(r["eligible_for_proposal"],r["distinct_pdfs"],r["matching_passages"]),reverse=True)
    proposals=[r for r in results if r["eligible_for_proposal"]][:max(0,args.max_new_domains)]
    report={
        "method":"rule-based multi-label corpus topic discovery; not LLM topic modeling",
        "source_ontology":str(ontology), "ontology_triples":len(graph),
        "ontology_class_count":len(catalog), "existing_domains_supplied":selected,
        "pdfs_found":len(pdfs), "pdfs_read":scanned, "errors":errors,
        "thresholds":{"min_documents":args.min_documents,"min_passages":args.min_passages},
        "proposed_new_domains":[r["topic_domain"] for r in proposals],
        "all_topics":results,
        "warning":"Topic-domain suggestions are thematic, not evidence of a novel OWL subclass. Review evidence and class hierarchy before adding.",
    }
    Path(args.output).write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
    print("\n=== DOMAIN DISCOVERY ===")
    for r in results:
        status="PROPOSE" if r in proposals else ("COVERED" if r["already_covered"] else "NOT PROPOSED")
        print(f"[{status}] {r['topic_domain']} | {r['distinct_pdfs']} PDFs | {r['matching_passages']} passages")
        if r["coverage_reason"]: print("  "+r["coverage_reason"])
    print("\nProposed additional domains:", [r["topic_domain"] for r in proposals])
    print("Report:",args.output)
    if args.proposal_rdf:
        proposal=Graph()
        ns=Namespace("http://yourdomain.org/ontology/proposed-topics#")
        proposal.bind("topicproposal",ns)
        for r in proposals:
            slug=re.sub(r"[^A-Za-z0-9]+","_",r["topic_domain"]).strip("_")
            iri=ns[slug]
            proposal.add((iri,RDF.type,OWL.Class))
            proposal.add((iri,RDFS.label,Literal(r["topic_domain"])))
            proposal.add((iri,RDFS.comment,Literal(
                f"PROPOSED ONLY. Supported by {r['distinct_pdfs']} PDFs and {r['matching_passages']} matched passages. Review before integration.")))
        proposal.serialize(destination=args.proposal_rdf,format="turtle")
        print("Separate proposal ontology:",args.proposal_rdf)
    if errors:
        print(f"[WARNING] {len(errors)} PDFs could not be read; results are incomplete.",file=sys.stderr)


if __name__=="__main__":
    main()

#!/usr/bin/env python3
"""Corpus-wide topic-domain discovery against an existing RDF/OWL ontology.

Read-only by default. Produces an evidence-backed JSON report and optional
OWL proposal graph; never changes the source ontology.
"""
import argparse
import collections
import hashlib
import json
import re
import sys
import os
import tempfile
from pathlib import Path

from rdflib import Graph, Literal, Namespace, RDF, RDFS, OWL, URIRef

STOP = set("""the and for with from that this these those shall must may not are was were have has had into upon such each every any all other under within where when which their its through between pursuant accordance including includes include means defined section sections paragraph article act law state states controller processor consumer person persons data personal information processing disclose disclosure use using require required provided provide notwithstanding pursuant subject regarding respect part chapter title page senate bill""".split())
WORDS = re.compile(r"[A-Za-z][A-Za-z-]{2,}")
OBLIGATION = re.compile(r"\b(shall|must|may not|shall not|must not|is required to|are required to|prohibited from|has the right to|have the right to)\b", re.I)
NOISE = re.compile(r"\b(the general assembly (finds|declares)|legislative (findings|declaration)|purpose of this (act|part))\b", re.I)

# These are discovery labels, NOT assumed to exist as classes in the RDF.
# Only suggest labels that have corpus evidence and are not covered by
# user-specified existing domains or similarly named KG classes.
THEMES = {
    "Consumer Rights and Consent": [
        r"\bconsent\b", r"\bopt[- ]out\b", r"\bappeal\b", r"\bright to (access|delete|correct|know)\b",
        r"\bconsumer request\b", r"\bwithdraw consent\b", r"\bdata portability\b"],
    "Transparency and Privacy Notices": [
        r"\bprivacy notice\b", r"\bprivacy policy\b", r"\bnotice to consumers\b",
        r"\bpublicly available\b", r"\btransparen\w*\b", r"\bnotice of (collection|processing)\b"],
    "Retention and Deletion": [
        r"\bretention\b", r"\bretain\b", r"\bdelete\b", r"\bdeletion\b",
        r"\berase\b", r"\bdestruction\b", r"\bdata minimization\b"],
    "Risk Assessments and Accountability": [
        r"\bdata protection assessment\b", r"\brisk assessment\b",
        r"\bimpact assessment\b", r"\bdocument\w* compliance\b",
        r"\baccountab\w*\b", r"\bprivacy impact\b"],
    "Sensitive Data and Children": [
        r"\bsensitive (personal )?data\b", r"\bbiometric\b", r"\bgenetic\b",
        r"\bchild(?:ren)?\b", r"\bminor(?:s)?\b", r"\bprecise geolocation\b"],
    "Breach Notification and Incident Response": [
        r"\bdata breach\b", r"\bsecurity incident\b", r"\bbreach notification\b",
        r"\bnotify.{0,45}breach\b", r"\bincident response\b"],
    "Automated Decisions and Profiling": [
        r"\bprofiling\b", r"\bautomated decision\w*\b", r"\btargeted advertising\b",
        r"\balgorithmic\b", r"\bautomated processing\b"],
    "Third-Party Contracts and Vendor Oversight": [
        r"\bprocessor contract\b", r"\bcontractual obligation\b",
        r"\bthird.party agreement\b", r"\bsubprocessor\b",
        r"\bprocessor shall\b", r"\bcontroller.processor\b"],
    "Enforcement and Regulatory Reporting": [
        r"\battorney general\b", r"\bcivil penalty\b", r"\benforcement\b",
        r"\bregulatory authority\b", r"\breport to\b", r"\bcure period\b"],
}
THEME_RE = {k: [re.compile(p, re.I) for p in pats] for k,pats in THEMES.items()}


def extract_pdf(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError as exc:
            raise RuntimeError("Install a PDF reader: py -m pip install pypdf") from exc
    reader = PdfReader(str(path))
    pages = [(i+1, page.extract_text() or "") for i,page in enumerate(reader.pages)]
    if not any(t.strip() for _,t in pages):
        raise ValueError("No extractable text (scanned PDFs need OCR).")
    return pages


def passages_from_page(text):
    # Split at punctuation and line breaks, retaining a bounded context window.
    text = re.sub(r"(?m)^\s*(?:PAGE\s+\d+[-–]?)?(?:SENATE|HOUSE)\s+BILL\s+\d+[-\d]*\s*$", " ", text, flags=re.I)
    text = re.sub(r"\s+", " ", text)
    parts = re.split(r"(?<=[.;])\s+(?=[A-Z(0-9])", text)
    # Group nearby short fragments to preserve context, but don't mix pages.
    buf = ""
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if len(buf) + len(part) < 180:
            buf = (buf + " " + part).strip()
            continue
        if buf:
            yield buf
        buf = part
        while len(buf) > 1100:
            boundary = buf.rfind(" ", 0, 1050)
            if boundary < 300:
                boundary = 1050
            yield buf[:boundary].strip()
            buf = buf[boundary:].strip()
    if buf:
        yield buf


def name_of(iri, graph):
    label = next(iter(graph.objects(iri, RDFS.label)), None)
    if label:
        return str(label)
    return re.sub(r"[_-]+", " ", str(iri).rsplit("#",1)[-1].rsplit("/",1)[-1])


def normalize(s):
    return set(x.lower() for x in WORDS.findall(s) if x.lower() not in STOP)


def class_inventory(graph):
    classes = set(graph.subjects(RDF.type, OWL.Class))
    classes.update(graph.subjects(RDFS.subClassOf, None))
    classes.update(o for o in graph.objects(None, RDFS.subClassOf) if isinstance(o, URIRef))
    return sorted([{"iri": str(c), "label": name_of(c,graph)} for c in classes],
                  key=lambda x: x["label"].lower())


def is_covered(theme, existing, catalog):
    tokens = normalize(theme)
    for label in existing:
        a = normalize(label)
        if a and (len(tokens & a)/len(a) >= .67 or len(tokens & a)/len(tokens) >= .75):
            return True, "Already covered by selected domain: "+label
    for c in catalog:
        a = normalize(c["label"])
        if a and len(a)>=2 and len(tokens & a)/len(a)>=.80 and len(tokens & a)/len(tokens)>=.60:
            return True, "Similar existing KG class: "+c["label"]
    return False, ""


def resolve_existing_parent(graph, catalog, supplied):
    """Resolve a parent by exact IRI or unambiguous label; never invent a parent."""
    matches = [c["iri"] for c in catalog
               if c["iri"] == supplied or c["label"].casefold() == supplied.casefold()]
    matches = list(dict.fromkeys(matches))
    if len(matches) != 1:
        raise ValueError(f"Parent {supplied!r} is not a unique existing OWL class ({len(matches)} matches)")
    iri = URIRef(matches[0])
    if (iri, RDF.type, OWL.Class) not in graph:
        raise ValueError(f"Parent is not declared owl:Class: {iri}")
    return iri


def apply_subclass_proposals(graph, catalog, proposals, parent_map, namespace):
    """Add reviewed proposals only; all parents must already exist in source KG."""
    if not namespace.startswith(('http://', 'https://')) or not namespace.endswith(('#', '/')):
        raise ValueError("--namespace must be an HTTP(S) IRI ending in # or /")
    if not proposals:
        return []
    plan = []
    used_iris = set()
    for item in proposals:
        label = item['topic_domain']
        if label not in parent_map:
            raise ValueError(f"No parent provided for {label!r}. Add it to --parent-map JSON; no writes performed.")
        parent = resolve_existing_parent(graph, catalog, parent_map[label])
        slug = re.sub(r'[^A-Za-z0-9]+', '_', label).strip('_')
        child = URIRef(namespace + slug)
        if child == parent or child in used_iris:
            raise ValueError(f"Invalid or duplicate subclass IRI: {child}")
        used_iris.add(child)
        if any(graph.triples((child, None, None))) or any(graph.triples((None, None, child))):
            if ((child, RDF.type, OWL.Class) in graph and
                    (child, RDFS.subClassOf, parent) in graph):
                plan.append((child, parent, item, False))
                continue
            raise ValueError(f"IRI collision with existing ontology entity: {child}")
        plan.append((child, parent, item, True))
    # Validation is complete before the first mutation.
    for child, parent, item, is_new in plan:
        if not is_new:
            continue
        graph.add((child, RDF.type, OWL.Class))
        graph.add((child, RDFS.subClassOf, parent))
        graph.add((child, RDFS.label, Literal(item['topic_domain'])))
        graph.add((child, RDFS.comment, Literal(
            f"Corpus-derived topic subclass; provisional pending legal/ontology review. "
            f"Evidence: {item['distinct_pdfs']} distinct PDFs, "
            f"{item['matching_passages']} matching passages. "
            "Classification is rule-based, not LLM-verified.")))
    return plan


def save_graph_atomic(graph, target):
    """Serialize to a temporary file, parse-check, then replace destination."""
    target = Path(target).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    suffix = target.suffix.lower()
    fmt = 'xml' if suffix in {'.rdf', '.xml', '.owl'} else 'turtle' if suffix == '.ttl' else None
    if not fmt:
        raise ValueError("Output extension must be .rdf, .owl, .xml or .ttl")
    fd, temp = tempfile.mkstemp(prefix='.kg-writing-', suffix=suffix, dir=str(target.parent))
    os.close(fd)
    try:
        graph.serialize(destination=temp, format=fmt)
        check = Graph()
        check.parse(temp, format=fmt)
        if len(check) != len(graph):
            raise RuntimeError("RDF round-trip triple count differs; refusing to commit")
        os.replace(temp, target)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def main():
    ap = argparse.ArgumentParser(description="Read-only corpus topic-domain discovery from PDF folder")
    ap.add_argument("--folder", required=True)
    ap.add_argument("--ontology", required=True)
    ap.add_argument("--existing-domains", nargs="+", default=None,
                    help="Names or IRIs of your THREE established domains; provide explicitly for accurate novelty checks")
    ap.add_argument("--max-new-domains", type=int, default=3)
    ap.add_argument("--min-documents", type=int, default=2,
                    help="Distinct PDFs needed for a suggested new domain")
    ap.add_argument("--min-passages", type=int, default=3)
    ap.add_argument("--output", default="topic_domain_discovery_report.json")
    ap.add_argument("--proposal-rdf", default=None,
                    help="Optional separate Turtle file with proposed classes (never modifies input RDF)")
    ap.add_argument("--apply-subclasses", action="store_true",
                    help="Actually write proposed OWL subclasses to --kg-output; requires --parent-map")
    ap.add_argument("--parent-map", default=None,
                    help="JSON file mapping each proposed topic label to an EXISTING parent class IRI/label")
    ap.add_argument("--kg-output", default=None,
                    help="Separate output .rdf/.owl/.ttl file; source ontology is never overwritten")
    ap.add_argument("--namespace", default="http://yourdomain.org/ontology/regulatory-topics#",
                    help="Namespace for new topic classes")
    ap.add_argument("--include-nonoperative", action="store_true",
                    help="Include all passages, not just those containing obligation cues")
    args = ap.parse_args()
    folder, ontology = Path(args.folder), Path(args.ontology)
    pdfs = sorted(folder.rglob("*.pdf"))
    if not pdfs:
        ap.error("No PDFs found in folder: "+str(folder))
    if args.apply_subclasses:
        if not args.parent_map or not args.kg_output:
            ap.error("--apply-subclasses requires --parent-map and --kg-output")
        if ontology.resolve() == Path(args.kg_output).resolve():
            ap.error("Refusing to overwrite the input ontology; choose a separate --kg-output")
        if Path(args.kg_output).exists():
            ap.error("Output file already exists; refusing to overwrite it. Choose a new output path.")
    graph = Graph()
    graph.parse(str(ontology))
    catalog = class_inventory(graph)
    print(f"[KG] {len(graph)} triples; {len(catalog)} classes", flush=True)
    print("[KG] Existing classes include:", ", ".join(x["label"] for x in catalog[:20]), flush=True)
    if args.existing_domains:
        selected = args.existing_domains
    else:
        # The RDF contains many classes; it does not identify three topic
        # domains explicitly. Avoid falsely claiming to know which three.
        selected = []
        print("[WARNING] No --existing-domains specified. Three established domains cannot be inferred reliably from this RDF.", flush=True)
    for d in selected:
        print(f"[EXISTING DOMAIN] {d}", flush=True)
    hits = {k: {"docs": set(), "passages": 0, "examples": [], "patterns": collections.Counter()}
            for k in THEMES}
    errors = []
    scanned = 0
    seen_global = set()
    for i,pdf in enumerate(pdfs,1):
        print(f"[PDF {i}/{len(pdfs)}] {pdf.name}", flush=True)
        try:
            pages = extract_pdf(pdf)
        except Exception as exc:
            errors.append({"file":str(pdf), "error":str(exc)})
            print(f"  [ERROR] {exc}", flush=True)
            continue
        scanned += 1
        for page,text in pages:
            for passage in passages_from_page(text):
                if not args.include_nonoperative and not OBLIGATION.search(passage):
                    continue
                if NOISE.search(passage):
                    continue
                digest = hashlib.sha256((pdf.name+passage.lower()).encode()).hexdigest()
                if digest in seen_global:
                    continue
                seen_global.add(digest)
                for theme,patterns in THEME_RE.items():
                    matched = [THEMES[theme][j] for j,pat in enumerate(patterns) if pat.search(passage)]
                    if not matched:
                        continue
                    h=hits[theme]
                    h["docs"].add(pdf.name)
                    h["passages"]+=1
                    h["patterns"].update(matched)
                    if len(h["examples"])<4:
                        h["examples"].append({"pdf":pdf.name, "page":page, "quote":passage[:650]})
    results=[]
    for theme,h in hits.items():
        covered,reason=is_covered(theme,selected,catalog)
        docs=len(h["docs"])
        eligible=docs>=args.min_documents and h["passages"]>=args.min_passages and not covered
        results.append({
            "topic_domain":theme, "distinct_pdfs":docs, "matching_passages":h["passages"],
            "already_covered":covered, "coverage_reason":reason,
            "eligible_for_proposal":eligible,
            "evidence":h["examples"],
            "matched_patterns":dict(h["patterns"].most_common(8)),
        })
    results.sort(key=lambda r:(r["eligible_for_proposal"],r["distinct_pdfs"],r["matching_passages"]),reverse=True)
    proposals=[r for r in results if r["eligible_for_proposal"]][:max(0,args.max_new_domains)]
    report={
        "method":"rule-based multi-label corpus topic discovery; not LLM topic modeling",
        "source_ontology":str(ontology), "ontology_triples":len(graph),
        "ontology_class_count":len(catalog), "existing_domains_supplied":selected,
        "pdfs_found":len(pdfs), "pdfs_read":scanned, "errors":errors,
        "thresholds":{"min_documents":args.min_documents,"min_passages":args.min_passages},
        "proposed_new_domains":[r["topic_domain"] for r in proposals],
        "all_topics":results,
        "warning":"Topic-domain suggestions are thematic, not evidence of a novel OWL subclass. Review evidence and class hierarchy before adding.",
    }
    Path(args.output).write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
    print("\n=== DOMAIN DISCOVERY ===")
    for r in results:
        status="PROPOSE" if r in proposals else ("COVERED" if r["already_covered"] else "NOT PROPOSED")
        print(f"[{status}] {r['topic_domain']} | {r['distinct_pdfs']} PDFs | {r['matching_passages']} passages")
        if r["coverage_reason"]: print("  "+r["coverage_reason"])
    print("\nProposed additional domains:", [r["topic_domain"] for r in proposals])
    print("Report:",args.output)
    if args.apply_subclasses:
        mapping = json.loads(Path(args.parent_map).read_text(encoding="utf-8"))
        if not isinstance(mapping, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in mapping.items()):
            raise ValueError("--parent-map must be a JSON object of topic labels to existing class IRIs/labels")
        before = len(graph)
        plan = apply_subclass_proposals(graph, catalog, proposals, mapping, args.namespace)
        save_graph_atomic(graph, args.kg_output)
        print(f"[KG WRITE] Saved {args.kg_output}; {sum(new for _,_,_,new in plan)} new subclasses; "
              f"{len(graph)-before} new triples; original KG unchanged.")
        for child, parent, _, is_new in plan:
            print(f"  [{'CREATED' if is_new else 'EXISTING'}] {child} rdfs:subClassOf {parent}")
    if args.proposal_rdf:
        proposal=Graph()
        ns=Namespace("http://yourdomain.org/ontology/proposed-topics#")
        proposal.bind("topicproposal",ns)
        for r in proposals:
            slug=re.sub(r"[^A-Za-z0-9]+","_",r["topic_domain"]).strip("_")
            iri=ns[slug]
            proposal.add((iri,RDF.type,OWL.Class))
            proposal.add((iri,RDFS.label,Literal(r["topic_domain"])))
            proposal.add((iri,RDFS.comment,Literal(
                f"PROPOSED ONLY. Supported by {r['distinct_pdfs']} PDFs and {r['matching_passages']} matched passages. Review before integration.")))
        proposal.serialize(destination=args.proposal_rdf,format="turtle")
        print("Separate proposal ontology:",args.proposal_rdf)
    if errors:
        print(f"[WARNING] {len(errors)} PDFs could not be read; results are incomplete.",file=sys.stderr)


if __name__=="__main__":
    main()

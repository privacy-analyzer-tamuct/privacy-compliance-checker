"""\
step1_agentic_regulation.py
==========================
Agentic ingestion and ontology-alignment for new IoT/privacy cybersecurity
regulations.

DESIGN
------
1. Extract individual statutory requirements from the source text with Groq.
2. Classify the cybersecurity control(s) addressed by each requirement.
3. Retrieve the existing OWL Means/Process hierarchy from the RDF graph.
4. Ask the alignment agent to choose one of:
       REUSE_EXISTING_CLASS
       CREATE_SUBCLASS
       CREATE_NEW_CONTROL
       NEEDS_HUMAN_REVIEW
5. Validate the proposal deterministically.
6. On approval, create a RegulatoryRequirement individual and link it to
   the selected control and Regulation individual. New OWL classes are only
   created when the agent proposes a genuinely distinct control.
7. Add legacy rdfs:hasLaw annotations to control classes for compatibility
   with the existing app's class-based assessment corpus.

IMPORTANT
---------
- LLM output is a proposal, never trusted as executable RDF.
- The graph is not changed unless apply=True is passed.
- Existing class IRIs are never renamed or deleted.
- A statutory requirement is represented as an individual, not automatically
  as a new OWL class.
- This module does not replace the current Flask route automatically. Import
  process_regulation_text() from app.py when ready to integrate it.

DEPENDENCIES
------------
rdflib, groq, PyPDF2. Groq credentials are supplied by the caller or by the
GROQ_API_KEY environment variable.

EXAMPLE
-------
from groq import Groq
from rdflib import Graph
from step1_agentic_regulation import process_regulation_pdf

g = Graph().parse("inferred_merged.rdf")
client = Groq()
result = process_regulation_pdf(
    pdf_path="new_law.pdf",
    graph=g,
    groq_client=client,
    law_id="TX_EXAMPLE_2026",
    law_label="Example Texas Cybersecurity Act",
    apply=False,                 # inspect proposals first
)
print(result["summary"])
for proposal in result["proposals"]:
    print(proposal)

# After reviewing the proposals, run again with apply=True and serialize g.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import re
import tempfile
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

try:
    from PyPDF2 import PdfReader
except ImportError:  # graph/text APIs remain usable without the PDF extra
    PdfReader = None  # type: ignore
from rdflib import Graph, URIRef, Literal, RDF, RDFS, OWL, XSD

try:
    from groq import Groq
except ImportError:  # allows importing the module for graph inspection/tests
    Groq = None  # type: ignore

LOGGER = logging.getLogger("agentic_regulation_ingestion")

# Keep the legacy predicate used by the existing assessment application.
HAS_LAW = URIRef("http://www.w3.org/2000/01/rdf-schema#hasLaw")
DCTERMS_CREATED = URIRef("http://purl.org/dc/terms/created")
DCTERMS_MODIFIED = URIRef("http://purl.org/dc/terms/modified")

DEFAULT_MODEL = "openai/gpt-oss-20b"
DEFAULT_MAX_CHARS = 2400
DEFAULT_MAX_REQUIREMENTS_PER_CHUNK = 30

DECISIONS = {
    "REUSE_EXISTING_CLASS",
    "CREATE_SUBCLASS",
    "CREATE_NEW_CONTROL",
    "NEEDS_HUMAN_REVIEW",
}

# These fields are stored on RegulatoryRequirement individuals. The namespace
# is selected from the active Means/Process namespace in the loaded ontology.
PROPERTY_NAMES = {
    "addresses_control": "addressesControl",
    "derived_from": "derivedFrom",
    "statutory_text": "hasStatutoryText",
    "statutory_section": "hasStatutorySection",
    "responsible_actor": "hasResponsibleActor",
    "required_action": "hasRequiredAction",
    "requirement_object": "hasRequirementObject",
    "condition": "hasCondition",
    "cybersecurity_purpose": "hasCybersecurityPurpose",
    "alignment_decision": "hasAlignmentDecision",
    "alignment_rationale": "hasAlignmentRationale",
    "alignment_confidence": "hasAlignmentConfidence",
    "requirement_identifier": "hasRequirementIdentifier",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().casefold()


def _slug(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9]+", "_", value.strip()).strip("_")
    if not value:
        value = "RegulatoryControl"
    if value[0].isdigit():
        value = "Control_" + value
    return value


def _local_name(iri: URIRef | str) -> str:
    return str(iri).rsplit("#", 1)[-1].rsplit("/", 1)[-1]


def read_pdf_text(pdf_path: str | Path) -> str:
    """Extract text from a PDF. Scanned/image-only PDFs need OCR upstream."""
    if PdfReader is None:
        raise RuntimeError("PyPDF2 is required for PDF ingestion: pip install PyPDF2")
    reader = PdfReader(str(pdf_path))
    pages = [(page.extract_text() or "").strip() for page in reader.pages]
    text = "\n\n".join(p for p in pages if p)
    if not text.strip():
        raise ValueError("No selectable text was extracted from the PDF; OCR is required.")
    return text


def _split_text(text: str, max_chars: int = DEFAULT_MAX_CHARS) -> list[str]:
    """Split by paragraph/sentence boundaries while keeping chunks manageable."""
    text = re.sub(r"\r", "\n", text)
    units = [u.strip() for u in re.split(r"\n\s*\n|(?<=[.!?])\s+(?=[A-Z(\[])", text) if u.strip()]
    chunks: list[str] = []
    current = ""
    for unit in units:
        if len(unit) > max_chars:
            if current:
                chunks.append(current)
                current = ""
            for start in range(0, len(unit), max_chars):
                chunks.append(unit[start:start + max_chars])
            continue
        if current and len(current) + len(unit) + 1 > max_chars:
            chunks.append(current)
            current = unit
        else:
            current = (current + "\n" + unit).strip()
    if current:
        chunks.append(current)
    return chunks


def _chat_json(
    client: Any,
    model: str,
    system: str,
    user: str,
    *,
    schema_name: str,
    schema: dict[str, Any],
    temperature: float = 0.0,
    max_tokens: int = 5000,
) -> dict[str, Any]:
    """Call Groq using strict Structured Outputs and parse the JSON object."""
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=temperature,
        max_tokens=max_tokens,
        response_format={
            "type": "json_schema",
            "json_schema": {
                "name": schema_name,
                "strict": True,
                "schema": schema,
            },
        },
    )
    content = response.choices[0].message.content
    if not content:
        raise ValueError(
            f"Groq returned an empty response for structured output '{schema_name}'."
        )
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Groq returned invalid JSON for '{schema_name}': {content[:500]}"
        ) from exc
    if not isinstance(parsed, dict):
        raise ValueError(f"Groq response for '{schema_name}' must be a JSON object.")
    return parsed


EXTRACTION_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "requirements": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "quoted_text": {"type": "string"},
                    "section": {"type": "string"},
                    "actor": {"type": "string"},
                    "action": {"type": "string"},
                    "object": {"type": "string"},
                    "condition": {"type": "string"},
                    "cybersecurity_purpose": {"type": "string"},
                    "candidate_controls": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "source_context": {"type": "string"},
                },
                "required": [
                    "quoted_text", "section", "actor", "action", "object",
                    "condition", "cybersecurity_purpose", "candidate_controls",
                    "source_context",
                ],
                "additionalProperties": False,
            },
        }
    },
    "required": ["requirements"],
    "additionalProperties": False,
}

CLASSIFICATION_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "control_concepts": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "label": {"type": "string"},
                    "kind": {"type": "string", "enum": ["Process", "Means"]},
                    "description": {"type": "string"},
                    "evidence": {"type": "string"},
                },
                "required": ["label", "kind", "description", "evidence"],
                "additionalProperties": False,
            },
        },
        "notes": {"type": "string"},
    },
    "required": ["control_concepts", "notes"],
    "additionalProperties": False,
}

ALIGNMENT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "decision": {
            "type": "string",
            "enum": [
                "REUSE_EXISTING_CLASS",
                "CREATE_SUBCLASS",
                "CREATE_NEW_CONTROL",
                "NEEDS_HUMAN_REVIEW",
            ],
        },
        "matched_class_iri": {"type": "string"},
        "matched_class_label": {"type": "string"},
        "new_class_label": {"type": "string"},
        "parent_class_iri": {"type": "string"},
        "class_kind": {"type": "string", "enum": ["Means", "Process"]},
        "confidence": {"type": "number"},
        "rationale": {"type": "string"},
        "rejected_candidates": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "iri": {"type": "string"},
                    "reason": {"type": "string"},
                },
                "required": ["iri", "reason"],
                "additionalProperties": False,
            },
        },
        "proposed_definition": {"type": "string"},
    },
    "required": [
        "decision", "matched_class_iri", "matched_class_label",
        "new_class_label", "parent_class_iri", "class_kind", "confidence",
        "rationale", "rejected_candidates", "proposed_definition",
    ],
    "additionalProperties": False,
}


def extract_requirements(text: str, groq_client: Any,
                         model: str = DEFAULT_MODEL) -> list[dict[str, Any]]:
    """Extract requirement-level records; statutory quotations must be verbatim."""
    system = """You are a legal-text extraction component for an IoT cybersecurity research system.
Extract only actual operative legal requirements from the supplied source text.
Do not invent obligations, legal interpretations, section numbers, actors, or wording.
A requirement can be a duty, prohibition, permission, standard, or other operative
rule; do not force a deontic label if it is not clear. Exclude recitals, definitions,
legislative findings, headings, and unrelated provisions unless they themselves
create an operative requirement.
Return JSON only with this schema:
{"requirements":[{"quoted_text":"exact contiguous quotation from source","section":"section/subsection or empty string","actor":"responsible actor or empty string","action":"operative action or empty string","object":"object of action or empty string","condition":"conditions/exceptions or empty string","cybersecurity_purpose":"plain-language purpose grounded in quote","candidate_controls":["short control concept", ...],"source_context":"brief context"}]}
Keep each quoted_text as short as possible while preserving the complete operative rule.
Do not paraphrase quoted_text. If no requirement is found, return an empty array."""

    extracted: list[dict[str, Any]] = []
    failures: list[str] = []

    def process_excerpt(chunk: str, tag: str, depth: int = 0) -> None:
        import time
        from groq import BadRequestError, RateLimitError
        try:
            payload = _chat_json(
                groq_client, model, system,
                f"Extract operative requirements from this source excerpt. "
                f""
                f"Keep fields concise, and quote only source text.\\nEXCERPT {tag}:\\n{chunk}",
                schema_name="requirement_extraction",
                schema=EXTRACTION_SCHEMA,
                max_tokens=2600,
            )
        except BadRequestError as exc:
            # Groq sometimes fails to generate a valid structured response for
            # dense legal text. Subdivide internally; never ask users to split PDFs.
            if ("json_validate_failed" not in str(exc) and
                    "Failed to validate JSON" not in str(exc)):
                raise
            if depth >= 5 or len(chunk) < 450:
                failures.append(f"{tag}: JSON generation failed at {len(chunk)} characters")
                return
            pieces = _split_text(chunk, max_chars=max(300, len(chunk) // 2))
            if len(pieces) < 2:
                middle = len(chunk) // 2
                pieces = [chunk[:middle], chunk[middle:]]
            LOGGER.warning("JSON validation failed for excerpt %s; retrying as %s smaller excerpts", tag, len(pieces))
            for index, piece in enumerate(pieces, 1):
                process_excerpt(piece, f"{tag}.{index}", depth + 1)
            return
        except RateLimitError:
            # SDK retries according to server retry-after; preserve failure if exhausted.
            raise

        items = payload.get("requirements", [])
        if not isinstance(items, list):
            failures.append(f"{tag}: requirements is not an array")
            return
        for item in items:
            if not isinstance(item, dict):
                continue
            quote = str(item.get("quoted_text", "")).strip()
            if len(quote) < 25 or _norm(quote) not in _norm(chunk):
                LOGGER.warning("Rejected non-verbatim/short requirement quote: %r", quote[:100])
                continue
            item["quoted_text"] = quote
            item["source_chunk"] = tag
            extracted.append(item)
        # Small spacing reduces back-to-back rate-limit bursts.
        time.sleep(0.35)

    for chunk_number, chunk in enumerate(_split_text(text), start=1):
        process_excerpt(chunk, str(chunk_number))
    if failures:
        raise RuntimeError(
            "Regulation extraction incomplete; ontology update blocked. "
            + "; ".join(failures[:12])
            + (f"; and {len(failures)-12} more" if len(failures)>12 else "")
        )

    # Deduplicate overlapping or repeated extraction results by normalized quote.
    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in extracted:
        key = _norm(item["quoted_text"])
        if key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def _find_class(g: Graph, label_or_iri: str | URIRef) -> URIRef | None:
    target = str(label_or_iri)
    for cls in g.subjects(RDF.type, OWL.Class):
        if not isinstance(cls, URIRef):
            continue
        if str(cls) == target:
            return cls
        if _norm(_local_name(cls).replace("_", " ")) == _norm(target):
            return cls
        if any(_norm(lbl) == _norm(target) for lbl in g.objects(cls, RDFS.label)):
            return cls
    return None


def _find_root_classes(g: Graph) -> dict[str, URIRef]:
    """Choose the active Means/Process class based on ontology hierarchy usage."""
    roots: dict[str, URIRef] = {}
    for kind in ("Means", "Process"):
        candidates = []
        for cls in g.subjects(RDF.type, OWL.Class):
            if not isinstance(cls, URIRef):
                continue
            labels = [_norm(x) for x in g.objects(cls, RDFS.label)]
            local = _norm(_local_name(cls).replace("_", " "))
            if local == _norm(kind) or _norm(kind) in labels:
                child_count = sum(1 for _ in g.subjects(RDFS.subClassOf, cls))
                # Prefer the root with the most actual children; breaks the
                # duplicate-namespace issue present in the supplied RDF.
                candidates.append((child_count, str(cls), cls))
        if candidates:
            candidates.sort(reverse=True, key=lambda x: (x[0], x[1]))
            roots[kind] = candidates[0][2]
    return roots


def _is_descendant(g: Graph, cls: URIRef, root: URIRef) -> bool:
    visited: set[URIRef] = set()
    stack = [cls]
    while stack:
        current = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        for parent in g.objects(current, RDFS.subClassOf):
            if parent == root:
                return True
            if isinstance(parent, URIRef):
                stack.append(parent)
    return False


def retrieve_control_catalog(g: Graph, max_classes: int = 100) -> tuple[list[dict[str, Any]], dict[str, URIRef]]:
    """Retrieve all active Means/Process descendants with definitions and context."""
    roots = _find_root_classes(g)
    catalog: list[dict[str, Any]] = []
    for kind, root in roots.items():
        for cls in g.subjects(RDF.type, OWL.Class):
            if not isinstance(cls, URIRef) or cls == root or not _is_descendant(g, cls, root):
                continue
            label_values = [str(x) for x in g.objects(cls, RDFS.label)]
            label = label_values[0] if label_values else _local_name(cls).replace("_", " ")
            comments = [str(x) for x in g.objects(cls, RDFS.comment)]
            parents = [str(x) for x in g.objects(cls, RDFS.subClassOf) if isinstance(x, URIRef)]
            law_context = [str(x)[:500] for x in g.objects(cls, HAS_LAW)][:3]
            catalog.append({
                "iri": str(cls),
                "label": label,
                "kind": kind,
                "definition": " ".join(comments)[:1200],
                "parents": parents,
                "existing_regulatory_context": law_context,
            })
    # stable ordering, then cap only if the ontology is unusually large
    catalog.sort(key=lambda x: (x["kind"], x["label"].casefold(), x["iri"]))
    return catalog[:max_classes], roots


def classify_requirement(requirement: dict[str, Any], groq_client: Any,
                          model: str = DEFAULT_MODEL) -> dict[str, Any]:
    """Normalize the extracted requirement into one or more control concepts."""
    system = """You classify statutory cybersecurity requirements by the privacy/cybersecurity
control activities they address. Do not decide whether an OWL class should be created;
that is a separate step. Return JSON only:
{"control_concepts":[{"label":"short reusable control name","kind":"Process or Means","description":"functional meaning","evidence":"words from requirement supporting this classification"}],"notes":"brief explanation"}
Use Process for an activity/workflow (e.g. vulnerability management, updates, incident
response). Use Means for a mechanism, capability, technical safeguard, or instrument
(e.g. authentication mechanism, encryption mechanism). Prefer a small number of concepts.
Do not use legal modality (obligation/prohibition/permission) as the control category."""
    payload = _chat_json(
        groq_client, model, system,
        "Classify this extracted statutory requirement.\n" + json.dumps(requirement, ensure_ascii=False),
        schema_name="control_classification",
        schema=CLASSIFICATION_SCHEMA,
        max_tokens=1800,
    )
    concepts = payload.get("control_concepts", [])
    if not isinstance(concepts, list):
        concepts = []
    valid = []
    for c in concepts:
        if not isinstance(c, dict):
            continue
        kind = str(c.get("kind", "Process")).strip().title()
        if kind not in {"Means", "Process"}:
            kind = "Process"
        label = re.sub(r"\s+", " ", str(c.get("label", "")).strip())
        if label:
            valid.append({
                "label": label,
                "kind": kind,
                "description": str(c.get("description", "")).strip(),
                "evidence": str(c.get("evidence", "")).strip(),
            })
    return {"control_concepts": valid, "notes": str(payload.get("notes", ""))}


def align_requirement(requirement: dict[str, Any], control_concept: dict[str, Any],
                      catalog: list[dict[str, Any]], roots: dict[str, URIRef],
                      groq_client: Any, model: str = DEFAULT_MODEL) -> dict[str, Any]:
    """Ask the LLM to propose reuse, subclass, new control, or review."""
    system = """You are an ontology-alignment agent for a regulatory-control knowledge graph.
Your task is to decide whether the underlying cybersecurity control in a new legal
requirement is already represented in the supplied ontology catalog.

Decision rules:
- REUSE_EXISTING_CLASS: same functional activity/mechanism is already represented.
- CREATE_SUBCLASS: the concept is a meaningful narrower specialization of an existing
  class, not merely a different legal condition, actor, deadline, threshold, or wording.
- CREATE_NEW_CONTROL: a genuinely distinct control activity/mechanism is absent from
  the catalog and cannot be accurately represented as a subclass of an existing class.
- NEEDS_HUMAN_REVIEW: ambiguity, competing matches, insufficient evidence, or uncertainty.

Do not create a new class just because a regulation has new wording or a new statutory
requirement. Multiple requirements/laws can connect to one reusable control class.
Do not treat related concepts as equivalent: e.g. vulnerability detection, remediation,
and disclosure can be distinct activities. Select Means or Process consistently with
whether the concept is a mechanism/capability or an activity/workflow.

Return JSON only with this schema:
{"decision":"...","matched_class_iri":"existing IRI or empty","matched_class_label":"existing label or empty","new_class_label":"only for CREATE_SUBCLASS/CREATE_NEW_CONTROL","parent_class_iri":"existing Means/Process or existing class IRI","class_kind":"Means or Process","confidence":0.0,"rationale":"specific comparison to candidates","rejected_candidates":[{"iri":"...","reason":"..."}],"proposed_definition":"definition for a proposed new class"}
Confidence is a heuristic, not a probability. Never invent an existing IRI; copy it exactly
from the catalog. For CREATE_NEW_CONTROL, parent_class_iri must be the supplied Means or
Process root matching class_kind. For CREATE_SUBCLASS, parent_class_iri should be the
existing class that it specializes. If you cannot follow these rules, choose review."""
    payload = _chat_json(
        groq_client, model, system,
        "NEW REQUIREMENT:\n" + json.dumps(requirement, ensure_ascii=False) +
        "\nCONTROL CONCEPT:\n" + json.dumps(control_concept, ensure_ascii=False) +
        "\nEXISTING ONTOLOGY CATALOG (authoritative IRIs):\n" +
        json.dumps(catalog, ensure_ascii=False),
        schema_name="ontology_alignment",
        schema=ALIGNMENT_SCHEMA,
        max_tokens=2500,
    )
    decision = str(payload.get("decision", "NEEDS_HUMAN_REVIEW")).upper().strip()
    if decision not in DECISIONS:
        decision = "NEEDS_HUMAN_REVIEW"
    confidence = payload.get("confidence", 0.0)
    try:
        confidence = max(0.0, min(1.0, float(confidence)))
    except (TypeError, ValueError):
        confidence = 0.0
    result = {
        "decision": decision,
        "matched_class_iri": str(payload.get("matched_class_iri", "")).strip(),
        "matched_class_label": str(payload.get("matched_class_label", "")).strip(),
        "new_class_label": str(payload.get("new_class_label", "")).strip(),
        "parent_class_iri": str(payload.get("parent_class_iri", "")).strip(),
        "class_kind": str(payload.get("class_kind", control_concept.get("kind", "Process"))).title(),
        "confidence": confidence,
        "rationale": str(payload.get("rationale", "")).strip(),
        "rejected_candidates": payload.get("rejected_candidates", []),
        "proposed_definition": str(payload.get("proposed_definition", control_concept.get("description", ""))).strip(),
    }
    return result


def validate_proposal(proposal: dict[str, Any], catalog: list[dict[str, Any]],
                      roots: dict[str, URIRef], min_confidence: float = 0.72) -> tuple[bool, str]:
    """Deterministic guardrail: validate references, labels, parent, and confidence."""
    decision = proposal.get("decision")
    if decision == "NEEDS_HUMAN_REVIEW":
        return False, "Agent explicitly requested human review."
    if float(proposal.get("confidence", 0.0)) < min_confidence:
        return False, f"Confidence below configured threshold ({min_confidence:.2f})."
    catalog_by_iri = {x["iri"]: x for x in catalog}
    kind = proposal.get("class_kind")
    if kind not in {"Means", "Process"}:
        return False, "class_kind must be Means or Process."

    if decision == "REUSE_EXISTING_CLASS":
        iri = proposal.get("matched_class_iri", "")
        if iri not in catalog_by_iri:
            return False, "Matched class IRI is not in the retrieved ontology catalog."
        if _norm(proposal.get("matched_class_label")) != _norm(catalog_by_iri[iri]["label"]):
            return False, "Matched class label does not match the selected IRI."
        return True, "Existing class reference validated."

    if decision in {"CREATE_SUBCLASS", "CREATE_NEW_CONTROL"}:
        label = proposal.get("new_class_label", "").strip()
        if not label or len(label) < 3:
            return False, "Proposed class label is missing or too short."
        if any(_norm(label) == _norm(c["label"]) for c in catalog):
            return False, "A class with this label already exists; reuse or review instead."
        parent = proposal.get("parent_class_iri", "")
        if decision == "CREATE_NEW_CONTROL":
            if kind not in roots or parent != str(roots[kind]):
                return False, f"New control must use the retrieved {kind} root as parent."
        else:
            if parent not in catalog_by_iri:
                return False, "Subclass parent must be an existing Means/Process descendant."
            if catalog_by_iri[parent]["kind"] != kind:
                return False, "Subclass kind does not match its parent's Means/Process branch."
        return True, "Proposed class label and parent validated."
    return False, "Unsupported decision."


def _safe_new_class_iri(g: Graph, namespace: str, label: str) -> URIRef:
    base = namespace.rstrip("#/") + "#"
    slug = _slug(label)
    candidate = URIRef(base + slug)
    if not any(g.triples((candidate, None, None))):
        return candidate
    suffix = 2
    while any(g.triples((URIRef(base + f"{slug}_{suffix}"), None, None))):
        suffix += 1
    return URIRef(base + f"{slug}_{suffix}")


def _ensure_class(g: Graph, iri: URIRef, label: str, parent: URIRef,
                  definition: str = "") -> None:
    g.add((iri, RDF.type, OWL.Class))
    g.add((iri, RDFS.label, Literal(label)))
    g.add((iri, RDFS.subClassOf, parent))
    if definition:
        g.add((iri, RDFS.comment, Literal(definition)))
    g.add((iri, DCTERMS_CREATED, Literal(_now(), datatype=XSD.dateTime)))


def _ensure_regulatory_schema(g: Graph, namespace: str) -> dict[str, URIRef]:
    ns = namespace.rstrip("#/") + "#"
    requirement_class = URIRef(ns + "RegulatoryRequirement")
    regulation_class = URIRef(ns + "Regulation")
    g.add((requirement_class, RDF.type, OWL.Class))
    g.add((requirement_class, RDFS.label, Literal("Regulatory Requirement")))
    g.add((requirement_class, RDFS.subClassOf, OWL.Thing))
    g.add((regulation_class, RDF.type, OWL.Class))
    g.add((regulation_class, RDFS.label, Literal("Regulation")))
    g.add((regulation_class, RDFS.subClassOf, OWL.Thing))
    properties: dict[str, URIRef] = {}
    for key, local in PROPERTY_NAMES.items():
        prop = URIRef(ns + local)
        g.add((prop, RDF.type, OWL.ObjectProperty if key in {"addresses_control", "derived_from"} else OWL.DatatypeProperty))
        properties[key] = prop
    return {"requirement_class": requirement_class, "regulation_class": regulation_class, **properties}


def _add_requirement_record(g: Graph, req: dict[str, Any], req_index: int,
                            law_id: str, law_label: str, control_iri: URIRef,
                            decision: dict[str, Any], schema: dict[str, URIRef],
                            regulation_iri: URIRef) -> URIRef:
    ns = str(schema["requirement_class"]).rsplit("#", 1)[0] + "#"
    identifier = f"{_slug(law_id)}_REQ_{req_index:04d}"
    req_iri = URIRef(ns + identifier)
    # Avoid collisions if a regulation is re-ingested.
    if any(g.triples((req_iri, None, None))):
        existing_text = next(iter(g.objects(req_iri, schema["statutory_text"])), None)
        if not (existing_text and _norm(existing_text) == _norm(req.get("quoted_text", ""))):
            req_iri = URIRef(ns + identifier + "_" + uuid.uuid4().hex[:8])

    g.add((req_iri, RDF.type, schema["requirement_class"]))
    g.add((req_iri, RDF.type, OWL.NamedIndividual))
    g.add((req_iri, RDFS.label, Literal(f"{law_label} Requirement {req_index}")))
    g.add((req_iri, schema["requirement_identifier"], Literal(identifier)))
    g.add((req_iri, schema["statutory_text"], Literal(req.get("quoted_text", ""))))
    g.add((req_iri, schema["derived_from"], regulation_iri))
    g.add((req_iri, schema["addresses_control"], control_iri))
    g.add((req_iri, schema["alignment_decision"], Literal(decision["decision"])))
    g.add((req_iri, schema["alignment_rationale"], Literal(decision.get("rationale", ""))))
    g.add((req_iri, schema["alignment_confidence"], Literal(float(decision.get("confidence", 0.0)), datatype=XSD.decimal)))
    for key, source_key in (("statutory_section", "section"),
                            ("responsible_actor", "actor"),
                            ("required_action", "action"),
                            ("requirement_object", "object"),
                            ("condition", "condition"),
                            ("cybersecurity_purpose", "cybersecurity_purpose")):
        value = str(req.get(source_key, "")).strip()
        if value:
            g.add((req_iri, schema[key], Literal(value)))
    g.add((req_iri, DCTERMS_CREATED, Literal(_now(), datatype=XSD.dateTime)))

    # Compatibility: existing app builds its regulatory corpus from class
    # hasLaw annotations. The full statutory requirement remains on the
    # requirement individual; this class annotation makes the control visible
    # to the existing corpus without making the requirement itself a class.
    legacy_text = f"{law_label} [{law_id}] {req.get('quoted_text', '')}"
    g.add((control_iri, HAS_LAW, Literal(legacy_text)))
    return req_iri


def process_regulation_text(
    text: str,
    graph: Graph,
    groq_client: Any,
    law_id: str,
    law_label: str,
    *,
    model: str = DEFAULT_MODEL,
    apply: bool = False,
    min_confidence: float = 0.72,
    max_catalog_classes: int = 100,
) -> dict[str, Any]:
    """Extract, classify, align, validate and optionally apply a regulation.

    When apply=False, graph is not mutated. The return value includes proposals
    and a preview graph clone under `updated_graph` (not JSON serializable).
    When apply=True, approved changes are copied into the supplied graph.
    Human-review items are never inserted.
    """
    if not text or not text.strip():
        raise ValueError("Regulation text is empty.")
    if not law_id.strip() or not law_label.strip():
        raise ValueError("law_id and law_label are required.")
    if groq_client is None:
        raise ValueError("A configured Groq client is required.")

    catalog, roots = retrieve_control_catalog(graph, max_classes=max_catalog_classes)
    if not roots:
        raise ValueError("Could not locate Means or Process root classes in the ontology.")

    requirements = extract_requirements(text, groq_client, model=model)
    if not requirements:
        return {
            "law_id": law_id, "law_label": law_label, "requirements_extracted": 0,
            "proposals": [], "summary": {"reused": 0, "subclasses_created": 0,
            "new_controls_created": 0, "human_review": 0, "requirements_added": 0},
            "updated_graph": deepcopy(graph), "applied": False,
        }

    proposals: list[dict[str, Any]] = []
    for idx, requirement in enumerate(requirements, start=1):
        classification = classify_requirement(requirement, groq_client, model=model)
        concepts = classification["control_concepts"]
        if not concepts:
            proposals.append({
                "requirement_index": idx, "requirement": requirement,
                "classification": classification,
                "alignment": {"decision": "NEEDS_HUMAN_REVIEW", "confidence": 0.0,
                              "rationale": "No control concept could be identified."},
                "validated": False, "validation_reason": "No control concept could be identified.",
            })
            continue

        # Align each distinct candidate control. One statutory provision may
        # legitimately address more than one control; each mapping is reviewed.
        for concept in concepts:
            alignment = align_requirement(requirement, concept, catalog, roots, groq_client, model=model)
            valid, reason = validate_proposal(alignment, catalog, roots, min_confidence=min_confidence)
            proposals.append({
                "requirement_index": idx,
                "requirement": requirement,
                "classification": classification,
                "control_concept": concept,
                "alignment": alignment,
                "validated": valid,
                "validation_reason": reason,
            })

    # Build on a clone. This gives all-or-nothing behavior for the caller's
    # graph and prevents a failed serialization from leaving a half-updated KG.
    updated = deepcopy(graph)
    roots_updated = _find_root_classes(updated)
    namespace = str(next(iter(roots_updated.values()))).rsplit("#", 1)[0]
    schema = _ensure_regulatory_schema(updated, namespace)
    law_iri = URIRef(namespace + "#Regulation_" + _slug(law_id))
    updated.add((law_iri, RDF.type, schema["regulation_class"]))
    updated.add((law_iri, RDF.type, OWL.NamedIndividual))
    updated.add((law_iri, RDFS.label, Literal(law_label)))
    updated.add((law_iri, DCTERMS_MODIFIED, Literal(_now(), datatype=XSD.dateTime)))

    counts = {"reused": 0, "subclasses_created": 0, "new_controls_created": 0,
              "human_review": 0, "requirements_added": 0}
    committed_requirement_keys: set[tuple[int, str]] = set()
    requirement_records_added: set[int] = set()
    for proposal in proposals:
        alignment = proposal["alignment"]
        if not proposal["validated"]:
            counts["human_review"] += 1
            continue
        decision = alignment["decision"]
        if decision == "REUSE_EXISTING_CLASS":
            control_iri = URIRef(alignment["matched_class_iri"])
            counts["reused"] += 1
        elif decision in {"CREATE_SUBCLASS", "CREATE_NEW_CONTROL"}:
            parent_iri = URIRef(alignment["parent_class_iri"])
            proposed_label = alignment["new_class_label"]
            # Several requirements in one statute may independently propose
            # the same new control. Reuse the class created earlier in this
            # batch instead of generating duplicate classes with suffixed IRIs.
            control_iri = None
            for candidate in updated.subjects(RDF.type, OWL.Class):
                if not isinstance(candidate, URIRef):
                    continue
                labels = [str(x) for x in updated.objects(candidate, RDFS.label)]
                if any(_norm(x) == _norm(proposed_label) for x in labels) and \
                   (candidate, RDFS.subClassOf, parent_iri) in updated:
                    control_iri = candidate
                    break
            if control_iri is None:
                control_iri = _safe_new_class_iri(updated, namespace, proposed_label)
                _ensure_class(updated, control_iri, proposed_label, parent_iri,
                              alignment.get("proposed_definition", ""))
                if decision == "CREATE_SUBCLASS":
                    counts["subclasses_created"] += 1
                else:
                    counts["new_controls_created"] += 1
        else:
            counts["human_review"] += 1
            continue

        req_index = int(proposal["requirement_index"])
        key = (req_index, str(control_iri))
        if key in committed_requirement_keys:
            continue
        committed_requirement_keys.add(key)
        _add_requirement_record(
            updated, proposal["requirement"], req_index, law_id, law_label,
            control_iri, alignment, schema, law_iri,
        )
        requirement_records_added.add(req_index)
    counts["requirements_added"] = len(requirement_records_added)

    # Mark graph-level processing provenance. Does not replace statute versions.
    processing_record = URIRef(namespace + "#Ingestion_" + _slug(law_id) + "_" + uuid.uuid4().hex[:8])
    updated.add((processing_record, RDF.type, OWL.NamedIndividual))
    updated.add((processing_record, RDFS.label, Literal(f"Agentic ingestion: {law_label}")))
    updated.add((processing_record, DCTERMS_CREATED, Literal(_now(), datatype=XSD.dateTime)))

    if apply:
        graph.remove((None, None, None))
        for triple in updated:
            graph.add(triple)

    return {
        "law_id": law_id,
        "law_label": law_label,
        "requirements_extracted": len(requirements),
        "proposals": proposals,
        "summary": counts,
        "applied": bool(apply),
        "updated_graph": updated,
    }


def process_regulation_pdf(
    pdf_path: str | Path,
    graph: Graph,
    groq_client: Any,
    law_id: str,
    law_label: str,
    **kwargs: Any,
) -> dict[str, Any]:
    return process_regulation_text(
        read_pdf_text(pdf_path), graph, groq_client, law_id, law_label, **kwargs
    )


def save_graph_atomic(graph: Graph, output_path: str | Path, rdf_format: str = "xml") -> None:
    """Serialize to a temporary file, then atomically replace destination."""
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=output.stem + "_", suffix=output.suffix,
                                     dir=str(output.parent))
    os.close(fd)
    try:
        graph.serialize(destination=temp_name, format=rdf_format)
        os.replace(temp_name, output)
    except Exception:
        try:
            os.remove(temp_name)
        except OSError:
            pass
        raise



def register_law_in_config(config_path: str | Path, law_id: str, law_label: str,
                           keywords: list[str] | None = None) -> bool:
    """Register the law for the existing app's regulation selectors/coverage."""
    path = Path(config_path)
    if not path.exists():
        LOGGER.warning("Config file %s not found; law was not registered there.", path)
        return False
    config = json.loads(path.read_text(encoding="utf-8"))
    laws = config.setdefault("laws", [])
    if any(str(item.get("id", "")).casefold() == law_id.casefold() for item in laws):
        LOGGER.info("Law %s is already registered in %s", law_id, path)
        return False
    laws.append({
        "id": law_id,
        "label": law_label,
        "keywords": list(dict.fromkeys(keywords or [law_label, law_id.replace("_", " ")])),
    })
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temp, path)
    return True

def _proposal_for_report(proposal: dict[str, Any]) -> dict[str, Any]:
    """Remove bulky source text duplication from CLI JSON report."""
    req = proposal.get("requirement", {})
    align = proposal.get("alignment", {})
    concept = proposal.get("control_concept", {})
    return {
        "requirement_index": proposal.get("requirement_index"),
        "requirement_text": req.get("quoted_text", ""),
        "section": req.get("section", ""),
        "control_concept": concept.get("label", ""),
        "decision": align.get("decision", "NEEDS_HUMAN_REVIEW"),
        "matched_class": align.get("matched_class_label", ""),
        "new_class": align.get("new_class_label", ""),
        "parent_class_iri": align.get("parent_class_iri", ""),
        "confidence": align.get("confidence", 0.0),
        "rationale": align.get("rationale", ""),
        "validated": proposal.get("validated", False),
        "validation_reason": proposal.get("validation_reason", ""),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Agentically ingest a regulation into the IoT cybersecurity KG.")
    parser.add_argument("--pdf", required=True, help="Regulation PDF path")
    parser.add_argument("--ontology", required=True, help="Input/output RDF ontology path")
    parser.add_argument("--law-id", required=True, help="Stable law ID, e.g. VA_VCDPA")
    parser.add_argument("--law-label", required=True, help="Human-readable regulation label")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--min-confidence", type=float, default=0.72)
    parser.add_argument("--apply", action="store_true", help="Commit validated proposals and save the ontology")
    parser.add_argument("--report", default="agentic_regulation_report.json")
    parser.add_argument("--config", default="config.json", help="Optional app config.json to register the law")
    args = parser.parse_args()

    if Groq is None:
        raise RuntimeError("Install the groq package: pip install groq")
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError("GROQ_API_KEY environment variable is not set.")

    graph = Graph()
    graph.parse(args.ontology)
    client = Groq(api_key=api_key)
    result = process_regulation_pdf(
        args.pdf, graph, client, args.law_id, args.law_label,
        model=args.model, apply=args.apply, min_confidence=args.min_confidence,
    )

    report = {
        "law_id": result["law_id"],
        "law_label": result["law_label"],
        "requirements_extracted": result["requirements_extracted"],
        "summary": result["summary"],
        "applied": result["applied"],
        "proposals": [_proposal_for_report(p) for p in result["proposals"]],
    }
    Path(args.report).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "proposals"}, indent=2))
    print(f"Detailed report: {Path(args.report).resolve()}")

    if args.apply:
        save_graph_atomic(result["updated_graph"], args.ontology, rdf_format="xml")
        print(f"Ontology updated: {Path(args.ontology).resolve()}")
        registered = register_law_in_config(
            args.config, args.law_id, args.law_label,
            [args.law_label, args.law_id.replace("_", " ")],
        )
        if registered:
            print(f"Registered {args.law_id} in {Path(args.config).resolve()}")
    else:
        print("DRY RUN: ontology was not modified. Review the report and rerun with --apply to commit.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()

"""

What this script does, step by step:
  1. Reads a regulation PDF (e.g. Texas HB 2395, Oregon HB 2395,
     California SB-327, NIST IR 8259, etc.)
  2. Uses the existing semantic extractor pattern to pull out
     entities (candidate classes) and relationships (triples).
  3. For each candidate class:
       - If a class with that label ALREADY EXISTS in the ontology,
         we simply ANNOTATE it with a hasLaw literal tying it to the
         new regulation (no duplicate class is created).
       - If the class DOES NOT EXIST, we CREATE it as a new
         owl:Class and add the triples describing it.
  4. Writes the new law ID into config.json so the rest of the
     app (law coverage, dropdown, etc.) picks it up automatically.

How to run (standalone demo):
    python step1_add_regulation.py --pdf HB2395.pdf \
        --law-id TX_HB_2395 --law-label "Texas HB 2395"

This is the SAME pattern the previous students used for NIST and
IoT Act — just generalized so any new regulation can be plugged in.
"""

import argparse
import json
import os
import re
from pathlib import Path

from PyPDF2 import PdfReader
from rdflib import Graph, URIRef, Literal, RDF, RDFS, OWL
from sentence_transformers import SentenceTransformer, util


# ---------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------
CONFIG_PATH = "config.json"
HAS_LAW_PRED = URIRef("http://www.w3.org/2000/01/rdf-schema#hasLaw")

# Seed ontology entities — same list used by semantic_policy_extractor.py.
# When a candidate class name from the PDF is semantically close to one
# of these, we treat it as a MATCH (annotate), otherwise we create a NEW class.
SEED_ENTITIES = [
    "IoT Device", "Manufacturer", "Federal Agency", "Cybersecurity Standard",
    "Personal Information", "Service Provider", "Customer", "Website",
    "Privacy Policy", "Data Breach", "Children", "Email", "Transaction",
    "Cookie", "User", "Data Processor", "Data Collector", "Law",
    "Policy", "Affiliate", "Subsidiary", "Division", "Franchisee",
    "Stakeholder", "Regulatory Body", "Security Feature", "Network Interface",
]



# STEP 1
def read_pdf_text(pdf_path: str) -> str:
    """Extract raw text from the uploaded regulation PDF."""
    reader = PdfReader(pdf_path)
    chunks = []
    for page in reader.pages:
        t = page.extract_text() or ""
        if t.strip():
            chunks.append(t)
    return "\n\n".join(chunks)


# STEP 1b: Pull candidate entities out of the regulation text
def extract_candidate_classes(text: str, model: SentenceTransformer, top_n: int = 15):
    sentences = re.split(r"(?<=[.!?])\s+", text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 20]

    if not sentences:
        return [], []

    # --- Matched seed entities (these will be annotated, not recreated) ---
    sent_emb = model.encode(sentences, convert_to_tensor=True, normalize_embeddings=True)
    seed_emb = model.encode(SEED_ENTITIES, convert_to_tensor=True, normalize_embeddings=True)

    sims = util.cos_sim(sent_emb, seed_emb)  # shape: (num_sentences, num_seeds)
    hit_counts = {e: 0 for e in SEED_ENTITIES}
    hit_sentences = {e: [] for e in SEED_ENTITIES}

    for i, sentence in enumerate(sentences):
        best_idx = int(sims[i].argmax())
        best_score = float(sims[i][best_idx])
        if best_score >= 0.35:  # tunable threshold
            entity = SEED_ENTITIES[best_idx]
            hit_counts[entity] += 1
            if len(hit_sentences[entity]) < 3:
                hit_sentences[entity].append(sentence)

    matched_existing = [
        {"label": e, "example_sentences": hit_sentences[e]}
        for e, c in sorted(hit_counts.items(), key=lambda kv: -kv[1])
        if c > 0
    ][:top_n]

    # --- Candidate NEW classes: capitalized phrases not near any seed ---
    phrase_re = re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})\b")
    candidate_new = {}
    seed_lower = {s.lower() for s in SEED_ENTITIES}

    for sentence in sentences:
        for m in phrase_re.findall(sentence):
            key = m.strip()
            if key.lower() in seed_lower:
                continue
            # Skip phrases that are common but useless
            if key.lower() in {"united states", "privacy policy", "section one"}:
                continue
            candidate_new.setdefault(key, []).append(sentence)

    # Keep phrases that appear in 2+ sentences (avoid one-off noise)
    new_classes = [
        {"label": k, "example_sentences": v[:3]}
        for k, v in candidate_new.items()
        if len(v) >= 2
    ][:top_n]

    return matched_existing, new_classes


# ---------------------------------------------------------------
# STEP 1c: Apply to the knowledge graph
# ---------------------------------------------------------------
def slug(label: str) -> str:
    return re.sub(r"\W+", "_", label.strip())


def find_existing_class(g: Graph, label: str):
    """
    Return the IRI of an existing owl:Class whose rdfs:label OR local
    name matches `label` (case-insensitive). Otherwise None.
    """
    target = label.lower().strip()
    for c in g.subjects(RDF.type, OWL.Class):
        if not isinstance(c, URIRef):
            continue
        # Check labels
        for lbl in g.objects(c, RDFS.label):
            if str(lbl).lower().strip() == target:
                return c
        # Check local name
        local = str(c).rsplit("#", 1)[-1].rsplit("/", 1)[-1]
        local_clean = re.sub(r"([a-z])([A-Z])", r"\1 \2", local).replace("_", " ").lower().strip()
        if local_clean == target:
            return c
    return None


def annotate_existing_class(g: Graph, class_iri: URIRef, law_label: str, snippets: list):
    """
    Class already exists → just attach a hasLaw literal that mentions
    the new law and a couple of example sentences. This is the
    'annotate' path from the requirements.
    """
    text = f"{law_label}. " + " ".join(snippets[:2])
    g.add((class_iri, HAS_LAW_PRED, Literal(text)))


def create_new_class(g: Graph, base_iri: str, label: str, law_label: str, snippets: list):
    """
    Class doesn't exist → create a new owl:Class with label, comment,
    and a hasLaw annotation pointing at the new regulation.
    This is the 'encode into the KG through triples' path.
    """
    new_iri = URIRef(base_iri + slug(label))
    g.add((new_iri, RDF.type, OWL.Class))
    g.add((new_iri, RDFS.label, Literal(label)))
    if snippets:
        g.add((new_iri, RDFS.comment, Literal(snippets[0])))
    text = f"{law_label}. " + " ".join(snippets[:2])
    g.add((new_iri, HAS_LAW_PRED, Literal(text)))
    return new_iri


# ---------------------------------------------------------------
# STEP 1d: Register the new law in config.json so the rest of the
# app knows about it (dropdowns, coverage, etc.)
# ---------------------------------------------------------------
def register_law_in_config(config_path: str, law_id: str, law_label: str, keywords: list):
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    existing_ids = {law["id"] for law in cfg.get("laws", [])}
    if law_id in existing_ids:
        print(f"[config] Law {law_id} already registered — skipping.")
        return

    cfg.setdefault("laws", []).append({
        "id": law_id,
        "label": law_label,
        "keywords": keywords,
    })

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    print(f"[config] Registered new law: {law_label} ({law_id})")



# ---------------------------------------------------------------
# READ-ONLY REQUIREMENT -> EXISTING KG CLASS RECOMMENDATIONS
# ---------------------------------------------------------------
NON_OPERATIVE_PATTERNS = (
    re.compile(r"\bdeclares\s+that\b", re.I),
    re.compile(r"\b(?:general assembly|legislature)\s+finds\b", re.I),
    re.compile(r"\blegislative\s+(?:findings|declaration)\b", re.I),
    re.compile(r"\bpurpose\s+of\s+this\s+(?:act|part)\b", re.I),
)


def is_non_operative_declaration(text):
    """Conservative screen for clearly identified legislative findings/purpose."""
    return any(pattern.search(text) for pattern in NON_OPERATIVE_PATTERNS)

#step 2
def requirement_sentences(text):
    normalized = " ".join(text.split())
    parts = re.split(r"(?<=[.;])\s+(?=[A-Z(0-9])", normalized)
    cues = re.compile(
        r"\b(must|shall|should|is required to|are required to|"
        r"may not|shall not|must not|prohibited|require(?:s|d)?|"
        r"notify|disclose|provide|obtain consent|implement|maintain)\b",
        re.I,
    )
    seen = set()
    for part in parts:
        part = part.strip()
        if 35 <= len(part) <= 1800 and cues.search(part) and not is_non_operative_declaration(part):
            key = re.sub(r"\W+", "", part).lower()
            if key not in seen:
                seen.add(key)
                yield part

#step 3a
def ontology_class_catalog(graph):
    catalog = []
    for iri in set(graph.subjects(RDF.type, OWL.Class)):
        if not isinstance(iri, URIRef):
            continue
        if (iri, OWL.deprecated, Literal(True)) in graph:
            continue
        labels = [str(x) for x in graph.objects(iri, RDFS.label)]
        local = str(iri).rsplit("#", 1)[-1].rsplit("/", 1)[-1]
        label = labels[0] if labels else re.sub(r"([a-z])([A-Z])", r"\1 \2", local).replace("_", " ")
        comments = [str(x) for x in graph.objects(iri, RDFS.comment)]
        laws = [str(x) for x in graph.objects(iri, HAS_LAW_PRED)]
        # Use actual KG descriptions rather than hardcoded seed entities.
        description = " ".join([label] * 3 + comments[:2] + laws[:3])[:3500]
        catalog.append((label, str(iri), description))
    return sorted(catalog)

#step 5
def agent_decide(client, model_name, requirement, candidates, domains):
    """LLM makes a grounded proposal; deterministic checks gate its output."""
    import json
    options = [
        {"label": label, "iri": iri, "similarity": round(score, 3),
         "description": description[:650]}
        for label, iri, description, score in candidates
    ]
    system = (
        "You are a regulatory-control ontology alignment agent. "
        "Classify the underlying regulatory CONTROL, not the legal actor, law title, "
        "deadline, or a random capitalized phrase. "
        "Return ONLY a JSON object with fields: action, domain, selected_iri, "
        "proposed_class_label, proposed_parent_iri, rationale. "
        "action must be exactly one of REUSE_EXISTING_CLASS, CREATE_SUBCLASS, "
        "CREATE_NEW_CONTROL, NEEDS_HUMAN_REVIEW. "
        "For reuse, selected_iri MUST be one of the supplied candidate IRIs. "
        "For subclass, proposed_parent_iri MUST be one of the supplied candidate IRIs. "
        "For new control, propose a reusable control name, not a statutory provision. "
        "Use NEEDS_HUMAN_REVIEW when evidence is insufficient. "
        "REUSE-FIRST POLICY: If an existing class can represent the underlying concept, "
        "choose REUSE_EXISTING_CLASS even if the provision adds conditions, obligations, "
        "actors, jurisdictions, deadlines, or different wording. "
        "Do not invent a subclass merely because the wording is more specific. "
        "CREATE_SUBCLASS only for a genuinely distinct, reusable kind of control that "
        "is logically a subtype of a retrieved existing CONTROL class; explain the "
        "distinct mechanism and the valid is-a relationship in rationale. "
        "CREATE_NEW_CONTROL only if no retrieved class adequately represents the concept. "
        "Personal Information is a data concept, not automatically a parent for "
        "organizational roles such as Responsible Data Custodian. "
        "For consumer-directed disclosure of personal data or customer records to third parties, "
        "prefer REUSE_EXISTING_CLASS with the existing Customer Records class when supplied. "
        "Do not invent Consumer-Directed Disclosure of Personal Data as a new class solely "
        "because the provision describes a particular disclosure scenario. "
        "For personal-data handling passages that introduce no distinct control, "
        "prefer reusing the existing Personal Information class if supplied. "
        "Legislative findings, declarations, and purpose statements are context, not "
        "automatically enforceable obligations; if presented, avoid proposing new classes. "
        "For reuse, set proposed_class_label and proposed_parent_iri to empty strings. "
        "Never claim a class exists unless its IRI appears in candidates. "
        "Do not create or update any graph."
    )
    user = json.dumps({
        "requirement": requirement,
        "domains": domains,
        "existing_kg_candidates": options,
    }, ensure_ascii=False)
    # Strict structured outputs are preferable to Groq JSON object mode.
    fields = ["action", "domain", "selected_iri", "proposed_class_label",
              "proposed_parent_iri", "rationale"]
    schema = {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": [
                "REUSE_EXISTING_CLASS", "CREATE_SUBCLASS",
                "CREATE_NEW_CONTROL", "NEEDS_HUMAN_REVIEW", "AGENT_ERROR"]},
            "domain": {"type": "string", "enum": domains},
            "selected_iri": {"type": "string"},
            "proposed_class_label": {"type": "string"},
            "proposed_parent_iri": {"type": "string"},
            "rationale": {"type": "string"},
        },
        "required": fields,
        "additionalProperties": False,
    }
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": user}]
    import logging
    from groq import BadRequestError
    try:
        response = client.chat.completions.create(
            model=model_name, messages=messages,
            response_format={"type": "json_schema", "json_schema": {
                "name": "ontology_alignment", "strict": True, "schema": schema}},
            temperature=0, max_tokens=1100,
        )
    except BadRequestError as exc:
        if "json_validate_failed" not in str(exc) and "Failed to validate JSON" not in str(exc):
            raise
        logging.warning("Structured output failed; retrying once without forced JSON mode")
        response = client.chat.completions.create(
            model=model_name, messages=messages, temperature=0,
            max_tokens=1100,
        )
    content = (response.choices[0].message.content or "").strip()
    if content.startswith("```"):
        content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    try:
        result = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError("Agent response is not valid JSON") from exc
    if not isinstance(result, dict):
        raise ValueError("Agent response is not a JSON object")
    allowed = {"REUSE_EXISTING_CLASS", "CREATE_SUBCLASS",
               "CREATE_NEW_CONTROL", "NEEDS_HUMAN_REVIEW"}
    valid_iris = {x["iri"] for x in options}
    action = result.get("action")
    if action not in allowed:
        raise ValueError("Agent returned invalid action")
    if action == "REUSE_EXISTING_CLASS" and result.get("selected_iri") not in valid_iris:
        raise ValueError("Agent selected a class outside retrieved KG candidates")
    if action == "CREATE_SUBCLASS" and result.get("proposed_parent_iri") not in valid_iris:
        raise ValueError("Agent proposed a parent outside retrieved KG candidates")
    if action in {"CREATE_SUBCLASS", "CREATE_NEW_CONTROL"}:
        label = str(result.get("proposed_class_label") or "").strip()
        if not label or len(label) > 100:
            raise ValueError("Agent did not provide a valid proposed class label")
    if result.get("domain") not in domains:
        raise ValueError("Agent returned unknown topic domain")
    if not str(result.get("rationale") or "").strip():
        raise ValueError("Agent omitted rationale")
    return result


def apply_reuse_policy(decision, candidates):
    """Block one known false subclass pattern without banning valid subclasses."""
    personal_iri = "http://yourdomain.org/ontology/laws#Personal_Information"
    available = {iri for _, iri, _, _ in candidates}
    label = str(decision.get("proposed_class_label") or "").strip().lower()
    # A custodian is an organizational role, not a subclass of information.
    # In this specific case, prefer thematic reuse rather than minting a class.
    if (decision.get("action") == "CREATE_SUBCLASS"
            and decision.get("proposed_parent_iri") == personal_iri
            and personal_iri in available
            and label in {"responsible data custodian", "responsible data custodians", "data custodian"}):
        decision = dict(decision)
        decision.update({
            "action": "REUSE_EXISTING_CLASS",
            "selected_iri": personal_iri,
            "proposed_class_label": "",
            "proposed_parent_iri": "",
            "rationale": "Reused Personal Information: a data custodian is not an is-a subtype of personal information; no distinct control class is justified by this passage.",
        })
    return decision


def apply_customer_records_policy(decision, requirement, candidates):
    """Reuse Customer Records for narrowly defined consumer-directed data disclosure.

    This is an ontology-alignment policy, not a claim that the passage is an
    enforceable requirement. It does not mutate the RDF graph.
    """
    customer_iri = "http://yourdomain.org/ontology/laws#Customer_Records"
    available = {iri for _, iri, _, _ in candidates}
    if customer_iri not in available:
        return decision
    if decision.get("action") == "AGENT_ERROR":
        return decision

    normalized = re.sub(r"\s+", " ", requirement).lower()
    personal_data = bool(re.search(r"\b(personal data|personal information|customer records)\b", normalized))
    disclosure = bool(re.search(r"\b(disclos(?:e|es|ed|ure)|shar(?:e|es|ing))\b", normalized))
    consumer_directed = bool(re.search(
        r"\b(consumer directs?|consumer-directed|consumer authoriz(?:es|ed)|"
        r"at the (consumer'?s|individual'?s) direction|"
        r"consumer intentionally discloses)\b", normalized
    ))
    third_party = bool(re.search(r"\bthird[ -]part(?:y|ies)\b", normalized))

    if personal_data and disclosure and consumer_directed and third_party:
        updated = dict(decision)
        updated.update({
            "action": "REUSE_EXISTING_CLASS",
            "domain": "Data Governance and Privacy Management",
            "selected_iri": customer_iri,
            "proposed_class_label": "",
            "proposed_parent_iri": "",
            "rationale": (
                "Ontology reuse policy: consumer-directed disclosure of personal data "
                "to a third party is mapped to the existing Customer Records class. "
                "The specific disclosure condition does not itself justify a new OWL class. "
                "This is a thematic mapping, not a determination that the passage "
                "imposes an enforceable obligation."
            ),
        })
        return updated
    return decision


def print_requirement_class_recommendations(pdf, ontology, threshold=0.40, top_k=5,
                                            model_name="openai/gpt-oss-20b",
                                            max_requirements=0):
    import os
    import time
    from dotenv import load_dotenv
    from groq import Groq
    load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env")
    key = os.getenv("GROQ_API_KEY")
    if not key:
        raise RuntimeError("GROQ_API_KEY missing from project .env or environment")
    client = Groq(api_key=key, max_retries=3, timeout=90)
    domains = [
        "Data Governance and Privacy Management",
        "Security and Risk Management",
        "Consumer Rights and Consent Management",
        "Regulatory Compliance and Transparency",
    ]
    print(f"[1] Reading regulation: {pdf}", flush=True)
    text = read_pdf_text(str(pdf))
    if not text.strip():
        raise ValueError("No extractable PDF text. Scanned PDFs may need OCR.")
    requirements = list(requirement_sentences(text))
    if max_requirements > 0:
        requirements = requirements[:max_requirements]
    print(f"[2] Found {len(requirements)} candidate requirement passages (heuristic)", flush=True)
    print(f"[3] Loading KG: {ontology}", flush=True)
    #step3b
    graph = Graph()
    graph.parse(str(ontology))
    catalog = ontology_class_catalog(graph)
    if not catalog:
        raise ValueError("No OWL classes found.")
    print(f"[4] Retrieving matches among {len(catalog)} existing classes", flush=True)
    embedder = SentenceTransformer("all-MiniLM-L6-v2")
    class_embeddings = embedder.encode(
        [x[2] for x in catalog], convert_to_tensor=True, normalize_embeddings=True
    )
    counts = {k: 0 for k in ["REUSE_EXISTING_CLASS", "CREATE_SUBCLASS",
                             "CREATE_NEW_CONTROL", "NEEDS_HUMAN_REVIEW", "AGENT_ERROR"]}
    for offset in range(0, len(requirements), 24):
        batch = requirements[offset:offset+24]
        embeddings = embedder.encode(batch, convert_to_tensor=True, normalize_embeddings=True)
        scores = util.cos_sim(embeddings, class_embeddings)
        for i, passage in enumerate(batch):
            number = offset+i+1
            ranked = scores[i].topk(k=min(top_k, len(catalog)))
            candidates = []
            for value, index in zip(ranked.values, ranked.indices):
                label, iri, description = catalog[int(index)]
                candidates.append((label, iri, description, float(value)))
            print(f"\\n{'='*75}\\nREQUIREMENT CANDIDATE {number} | {Path(pdf).name}", flush=True)
            print(f"TEXT: {passage}", flush=True)
            print("KG CANDIDATES:", flush=True)
            for label, iri, _, score in candidates:
                print(f"  {label} | score={score:.3f} | {iri}", flush=True)
            try:
                decision = apply_customer_records_policy(
                    apply_reuse_policy(
                        agent_decide(client, model_name, passage, candidates, domains), candidates
                    ), passage, candidates
                )
            except Exception as exc:
                # Do not fabricate a decision when the agent or API fails.
                decision = {"action": "AGENT_ERROR", "domain": "unresolved",
                            "selected_iri": "", "proposed_class_label": "",
                            "proposed_parent_iri": "",
                            "rationale": f"Agent unavailable or invalid response: {type(exc).__name__}: {exc}"}
            counts[decision["action"]] += 1
            print(f"AGENT STATUS: {decision['action']}", flush=True)
            print(f"TOPIC DOMAIN: {decision['domain']}", flush=True)
            print(f"EXISTING CLASS IRI: {decision.get('selected_iri') or '(none)'}", flush=True)
            print(f"PROPOSED CLASS: {decision.get('proposed_class_label') or '(none)'}", flush=True)
            print(f"PROPOSED PARENT: {decision.get('proposed_parent_iri') or '(none)'}", flush=True)
            print(f"REASON: {decision['rationale']}", flush=True)
            print("KG STATUS: PROPOSAL ONLY — NO CHANGES", flush=True)
            time.sleep(1.0)
            #step 7
    print(f"\\n{'='*75}\\nSUMMARY: {len(requirements)} candidate passages", flush=True)
    for action, count in counts.items():
        print(f"  {action}: {count}", flush=True)
    print("READ-ONLY: No ontology or config changes made.", flush=True)
    print("WARNING: Heuristic extraction is not guaranteed to find every legal requirement.", flush=True)


def main():
    ap = argparse.ArgumentParser(description="Agentic KG class decisions, printed only (read-only)")
    ap.add_argument("--pdf", required=True, help="Regulation PDF")
    ap.add_argument("--ontology", help="RDF/OWL path (or use config.json)")
    ap.add_argument("--config", default=CONFIG_PATH)
    ap.add_argument("--threshold", type=float, default=0.40)
    ap.add_argument("--top-k", type=int, default=5)
    ap.add_argument("--model", default="openai/gpt-oss-20b")
    ap.add_argument("--max-requirements", type=int, default=0,
                    help="Limit for a trial run; 0 means all candidates")
    args = ap.parse_args()
    if args.ontology:
        ontology = Path(args.ontology)
    else:
        config_path = Path(args.config).resolve()
        cfg = json.loads(config_path.read_text(encoding="utf-8"))
        ontology = Path(cfg["ontology_path"])
        if not ontology.is_absolute():
            ontology = config_path.parent / ontology
    print_requirement_class_recommendations(
        args.pdf, ontology, args.threshold, args.top_k,
        args.model, args.max_requirements
    )


if __name__ == "__main__":
    main()

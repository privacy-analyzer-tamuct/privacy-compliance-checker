"""

What this script does, step by step:
  1. Reads a regulation PDF (e.g. Texas HB 2395, Oregon HB 2395,
     California SB-327, NIST IR 8259, etc.)
  2. Uses the existing semantic extractor pattern to pull out
     entities (candidate classes) and relationships (triples).
  3. For each candidate class:
       - If a class with that label ALREADY EXISTS in the ontology,
         we simply ANNOTATE it with a hasLaw literal tying it to the
         new regulation (no duplicate class is created).
       - If the class DOES NOT EXIST, we CREATE it as a new
         owl:Class and add the triples describing it.
  4. Writes the new law ID into config.json so the rest of the
     app (law coverage, dropdown, etc.) picks it up automatically.

How to run (standalone demo):
    python step1_add_regulation.py --pdf HB2395.pdf \
        --law-id TX_HB_2395 --law-label "Texas HB 2395"

This is the SAME pattern the previous students used for NIST and
IoT Act — just generalized so any new regulation can be plugged in.
"""

import argparse
import json
import os
import re
from pathlib import Path

from PyPDF2 import PdfReader
from rdflib import Graph, URIRef, Literal, RDF, RDFS, OWL
from sentence_transformers import SentenceTransformer, util


# ---------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------
CONFIG_PATH = "config.json"
HAS_LAW_PRED = URIRef("http://www.w3.org/2000/01/rdf-schema#hasLaw")

# Seed ontology entities — same list used by semantic_policy_extractor.py.
# When a candidate class name from the PDF is semantically close to one
# of these, we treat it as a MATCH (annotate), otherwise we create a NEW class.
SEED_ENTITIES = [
    "IoT Device", "Manufacturer", "Federal Agency", "Cybersecurity Standard",
    "Personal Information", "Service Provider", "Customer", "Website",
    "Privacy Policy", "Data Breach", "Children", "Email", "Transaction",
    "Cookie", "User", "Data Processor", "Data Collector", "Law",
    "Policy", "Affiliate", "Subsidiary", "Division", "Franchisee",
    "Stakeholder", "Regulatory Body", "Security Feature", "Network Interface",
]


# ---------------------------------------------------------------
# STEP 1a: Read the PDF text
# ---------------------------------------------------------------
def read_pdf_text(pdf_path: str) -> str:
    """Extract raw text from the uploaded regulation PDF."""
    reader = PdfReader(pdf_path)
    chunks = []
    for page in reader.pages:
        t = page.extract_text() or ""
        if t.strip():
            chunks.append(t)
    return "\n\n".join(chunks)


# ---------------------------------------------------------------
# STEP 1b: Pull candidate entities out of the regulation text
# ---------------------------------------------------------------
def extract_candidate_classes(text: str, model: SentenceTransformer, top_n: int = 15):
    """
    Very lightweight candidate extraction:
      - Split the regulation into sentences.
      - For each sentence, find the closest seed entity by embedding.
      - Keep a short list of the most-referenced entities.
      - Also pull out capitalized multi-word noun phrases that DON'T
        match any seed — those are candidates for NEW classes.
    """
    sentences = re.split(r"(?<=[.!?])\s+", text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 20]

    if not sentences:
        return [], []

    # --- Matched seed entities (these will be annotated, not recreated) ---
    sent_emb = model.encode(sentences, convert_to_tensor=True, normalize_embeddings=True)
    seed_emb = model.encode(SEED_ENTITIES, convert_to_tensor=True, normalize_embeddings=True)

    sims = util.cos_sim(sent_emb, seed_emb)  # shape: (num_sentences, num_seeds)
    hit_counts = {e: 0 for e in SEED_ENTITIES}
    hit_sentences = {e: [] for e in SEED_ENTITIES}

    for i, sentence in enumerate(sentences):
        best_idx = int(sims[i].argmax())
        best_score = float(sims[i][best_idx])
        if best_score >= 0.35:  # tunable threshold
            entity = SEED_ENTITIES[best_idx]
            hit_counts[entity] += 1
            if len(hit_sentences[entity]) < 3:
                hit_sentences[entity].append(sentence)

    matched_existing = [
        {"label": e, "example_sentences": hit_sentences[e]}
        for e, c in sorted(hit_counts.items(), key=lambda kv: -kv[1])
        if c > 0
    ][:top_n]

    # --- Candidate NEW classes: capitalized phrases not near any seed ---
    phrase_re = re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})\b")
    candidate_new = {}
    seed_lower = {s.lower() for s in SEED_ENTITIES}

    for sentence in sentences:
        for m in phrase_re.findall(sentence):
            key = m.strip()
            if key.lower() in seed_lower:
                continue
            # Skip phrases that are common but useless
            if key.lower() in {"united states", "privacy policy", "section one"}:
                continue
            candidate_new.setdefault(key, []).append(sentence)

    # Keep phrases that appear in 2+ sentences (avoid one-off noise)
    new_classes = [
        {"label": k, "example_sentences": v[:3]}
        for k, v in candidate_new.items()
        if len(v) >= 2
    ][:top_n]

    return matched_existing, new_classes


# ---------------------------------------------------------------
# STEP 1c: Apply to the knowledge graph
# ---------------------------------------------------------------
def slug(label: str) -> str:
    return re.sub(r"\W+", "_", label.strip())


def find_existing_class(g: Graph, label: str):
    """
    Return the IRI of an existing owl:Class whose rdfs:label OR local
    name matches `label` (case-insensitive). Otherwise None.
    """
    target = label.lower().strip()
    for c in g.subjects(RDF.type, OWL.Class):
        if not isinstance(c, URIRef):
            continue
        # Check labels
        for lbl in g.objects(c, RDFS.label):
            if str(lbl).lower().strip() == target:
                return c
        # Check local name
        local = str(c).rsplit("#", 1)[-1].rsplit("/", 1)[-1]
        local_clean = re.sub(r"([a-z])([A-Z])", r"\1 \2", local).replace("_", " ").lower().strip()
        if local_clean == target:
            return c
    return None


def annotate_existing_class(g: Graph, class_iri: URIRef, law_label: str, snippets: list):
    """
    Class already exists → just attach a hasLaw literal that mentions
    the new law and a couple of example sentences. This is the
    'annotate' path from the requirements.
    """
    text = f"{law_label}. " + " ".join(snippets[:2])
    g.add((class_iri, HAS_LAW_PRED, Literal(text)))


def create_new_class(g: Graph, base_iri: str, label: str, law_label: str, snippets: list):
    """
    Class doesn't exist → create a new owl:Class with label, comment,
    and a hasLaw annotation pointing at the new regulation.
    This is the 'encode into the KG through triples' path.
    """
    new_iri = URIRef(base_iri + slug(label))
    g.add((new_iri, RDF.type, OWL.Class))
    g.add((new_iri, RDFS.label, Literal(label)))
    if snippets:
        g.add((new_iri, RDFS.comment, Literal(snippets[0])))
    text = f"{law_label}. " + " ".join(snippets[:2])
    g.add((new_iri, HAS_LAW_PRED, Literal(text)))
    return new_iri


# ---------------------------------------------------------------
# STEP 1d: Register the new law in config.json so the rest of the
# app knows about it (dropdowns, coverage, etc.)
# ---------------------------------------------------------------
def register_law_in_config(config_path: str, law_id: str, law_label: str, keywords: list):
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    existing_ids = {law["id"] for law in cfg.get("laws", [])}
    if law_id in existing_ids:
        print(f"[config] Law {law_id} already registered — skipping.")
        return

    cfg.setdefault("laws", []).append({
        "id": law_id,
        "label": law_label,
        "keywords": keywords,
    })

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    print(f"[config] Registered new law: {law_label} ({law_id})")



# ---------------------------------------------------------------
# READ-ONLY REQUIREMENT -> EXISTING KG CLASS RECOMMENDATIONS
# ---------------------------------------------------------------
def requirement_sentences(text):
    """Heuristic candidate extraction, not a complete legal parser."""
    normalized = " ".join(text.split())
    parts = re.split(r"(?<=[.;])\s+(?=[A-Z(0-9])", normalized)
    cues = re.compile(
        r"\b(must|shall|should|is required to|are required to|"
        r"may not|shall not|must not|prohibited|require(?:s|d)?|"
        r"notify|disclose|provide|obtain consent|implement|maintain)\b",
        re.I,
    )
    seen = set()
    for part in parts:
        part = part.strip()
        if 35 <= len(part) <= 1800 and cues.search(part):
            key = re.sub(r"\W+", "", part).lower()
            if key not in seen:
                seen.add(key)
                yield part


def ontology_class_catalog(graph):
    catalog = []
    for iri in set(graph.subjects(RDF.type, OWL.Class)):
        if not isinstance(iri, URIRef):
            continue
        if (iri, OWL.deprecated, Literal(True)) in graph:
            continue
        labels = [str(x) for x in graph.objects(iri, RDFS.label)]
        local = str(iri).rsplit("#", 1)[-1].rsplit("/", 1)[-1]
        label = labels[0] if labels else re.sub(r"([a-z])([A-Z])", r"\1 \2", local).replace("_", " ")
        comments = [str(x) for x in graph.objects(iri, RDFS.comment)]
        laws = [str(x) for x in graph.objects(iri, HAS_LAW_PRED)]
        # Use actual KG descriptions rather than hardcoded seed entities.
        description = " ".join([label] * 3 + comments[:2] + laws[:3])[:3500]
        catalog.append((label, str(iri), description))
    return sorted(catalog)


def print_requirement_class_recommendations(pdf, ontology, threshold=0.40, top_k=3):
    print(f"[1] Reading regulation: {pdf}", flush=True)
    text = read_pdf_text(str(pdf))
    if not text.strip():
        raise ValueError("No extractable PDF text. A scanned PDF may need OCR.")
    requirements = list(requirement_sentences(text))
    print(f"[2] Found {len(requirements)} candidate requirement passages (heuristic)", flush=True)
    print(f"[3] Reading existing KG: {ontology}", flush=True)
    graph = Graph()
    graph.parse(str(ontology))
    catalog = ontology_class_catalog(graph)
    if not catalog:
        raise ValueError("No OWL classes found in the ontology.")
    print(f"[4] Comparing with {len(catalog)} existing classes", flush=True)
    model = SentenceTransformer("all-MiniLM-L6-v2")
    class_embeddings = model.encode([x[2] for x in catalog], convert_to_tensor=True, normalize_embeddings=True)
    if not requirements:
        print("No candidate requirement passages detected. Nothing classified.")
        return
    mapped = review = 0
    for offset in range(0, len(requirements), 32):
        batch = requirements[offset:offset+32]
        embeddings = model.encode(batch, convert_to_tensor=True, normalize_embeddings=True)
        scores = util.cos_sim(embeddings, class_embeddings)
        for i, passage in enumerate(batch):
            number = offset + i + 1
            ranked = scores[i].topk(k=min(top_k, len(catalog)))
            best_score = float(ranked.values[0])
            print(f"\n{'='*75}\nREQUIREMENT CANDIDATE {number}\nSOURCE: {Path(pdf).name}")
            print(f"TEXT: {passage}")
            if best_score < threshold:
                review += 1
                print("RECOMMENDATION: HUMAN REVIEW / POSSIBLE NEW CONTROL")
                print("No existing class meets the similarity threshold.")
            else:
                mapped += 1
                print("RECOMMENDATION: REVIEW EXISTING CLASS MATCH")
            for rank, (value, index) in enumerate(zip(ranked.values, ranked.indices), 1):
                label, iri, _ = catalog[int(index)]
                print(f"  {rank}. CLASS: {label} | similarity: {float(value):.3f}")
                print(f"     IRI: {iri}")
    print(f"\n{'='*75}")
    print(f"SUMMARY: {len(requirements)} candidates; {mapped} above threshold; {review} require review")
    print("READ-ONLY: No ontology or config changes were made.")
    print("Similarity is a recommendation, not a validated legal classification.")


def main():
    ap = argparse.ArgumentParser(description="Print regulation requirements and recommended existing KG classes (read-only)")
    ap.add_argument("--pdf", required=True, help="Regulation PDF")
    ap.add_argument("--ontology", help="Path to RDF/OWL ontology (otherwise read config.json)")
    ap.add_argument("--config", default=CONFIG_PATH)
    ap.add_argument("--threshold", type=float, default=0.40)
    ap.add_argument("--top-k", type=int, default=3)
    args = ap.parse_args()
    if args.ontology:
        ontology = Path(args.ontology)
    else:
        config_path = Path(args.config).resolve()
        cfg = json.loads(config_path.read_text(encoding="utf-8"))
        ontology = Path(cfg["ontology_path"])
        if not ontology.is_absolute():
            ontology = config_path.parent / ontology
    print_requirement_class_recommendations(args.pdf, ontology, args.threshold, args.top_k)


if __name__ == "__main__":
    main()

"""Batch agentic classification of regulation PDFs against an OWL/RDF ontology.

This script scans a folder of selectable-text PDF statutes, extracts their
individual operative requirements, identifies the relevant cybersecurity
control, and decides whether each requirement should reuse an existing Means
or Process class, create a subclass, create a new control class, or be sent
for human review.

It delegates legal extraction/alignment to step1_agentic_regulation.py. Keep
that module in the same directory as this script.

SAFE DEFAULT: dry run. The source ontology is never changed unless --apply
is supplied. In dry-run mode, the PDFs are processed sequentially against an
in-memory working graph, so later PDFs can see valid class proposals from
earlier PDFs. Nothing is written to the source RDF file.

Install:
    pip install rdflib PyPDF2 groq python-dotenv

Set GROQ_API_KEY in the environment or a .env file.

Example:
    python step1_batch_regulation_folder.py \\
        --folder ./regulations \\
        --ontology ./inferred_merged.rdf

Commit reviewed proposals:
    python step1_batch_regulation_folder.py \\
        --folder ./regulations \\
        --ontology ./inferred_merged.rdf \\
        --apply

Optional metadata JSON maps PDF filenames (or filename stems) to law IDs and
labels. Example:
    {
      "Virginia_CDPA.pdf": {
        "law_id": "VA_CDPA",
        "law_label": "Virginia Consumer Data Protection Act"
      },
      "Colorado_Privacy_Act": {
        "law_id": "CO_CPA",
        "law_label": "Colorado Privacy Act"
      }
    }
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

from rdflib import Graph

try:
    from groq import Groq
except ImportError:
    Groq = None  # type: ignore

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from step1_agentic_regulation import (
    DEFAULT_MODEL,
    _proposal_for_report,
    process_regulation_pdf,
    register_law_in_config,
    save_graph_atomic,
)

LOGGER = logging.getLogger("batch_regulation_folder")


def safe_identifier(value: str) -> str:
    """Create a stable law ID from a filename when metadata is not supplied."""
    value = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").upper()
    return value or "UNNAMED_REGULATION"


def default_label(pdf_path: Path) -> str:
    """Turn a filename into a readable fallback legislation label."""
    return re.sub(r"[_-]+", " ", pdf_path.stem).strip() or pdf_path.name


def load_metadata(path: Path | None) -> dict[str, dict[str, str]]:
    if path is None:
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Metadata JSON must be an object keyed by PDF filename or stem.")
    normalized: dict[str, dict[str, str]] = {}
    for key, value in data.items():
        if not isinstance(value, dict):
            continue
        normalized[str(key).casefold()] = {
            "law_id": str(value.get("law_id", "")).strip(),
            "law_label": str(value.get("law_label", "")).strip(),
        }
    return normalized


def law_metadata(pdf_path: Path, metadata: dict[str, dict[str, str]]) -> tuple[str, str]:
    entry = metadata.get(pdf_path.name.casefold()) or metadata.get(pdf_path.stem.casefold()) or {}
    law_id = entry.get("law_id") or safe_identifier(pdf_path.stem)
    law_label = entry.get("law_label") or default_label(pdf_path)
    return law_id, law_label


def discover_pdfs(folder: Path, recursive: bool) -> list[Path]:
    if not folder.exists() or not folder.is_dir():
        raise NotADirectoryError(f"PDF folder does not exist or is not a directory: {folder}")
    iterator = folder.rglob("*.pdf") if recursive else folder.glob("*.pdf")
    # Include .PDF and other case variants on case-sensitive filesystems.
    pdfs = sorted((p for p in (folder.rglob("*") if recursive else folder.glob("*"))
                   if p.is_file() and p.suffix.casefold() == ".pdf"),
                  key=lambda p: str(p).casefold())
    return pdfs


def summarize_reports(items: list[dict[str, Any]]) -> dict[str, int]:
    totals = {
        "pdfs_found": len(items),
        "pdfs_processed": 0,
        "pdfs_failed": 0,
        "requirements_extracted": 0,
        "reused": 0,
        "subclasses_created": 0,
        "new_controls_created": 0,
        "human_review": 0,
        "requirements_added": 0,
    }
    for item in items:
        if item.get("status") == "processed":
            totals["pdfs_processed"] += 1
            summary = item.get("summary", {})
            totals["requirements_extracted"] += int(item.get("requirements_extracted", 0))
            for key in ("reused", "subclasses_created", "new_controls_created",
                        "human_review", "requirements_added"):
                totals[key] += int(summary.get(key, 0))
        else:
            totals["pdfs_failed"] += 1
    return totals


def run_batch(
    folder: Path,
    ontology_path: Path,
    *,
    recursive: bool = False,
    apply: bool = False,
    model: str = DEFAULT_MODEL,
    min_confidence: float = 0.72,
    report_path: Path = Path("agentic_regulation_folder_report.json"),
    metadata_path: Path | None = None,
    config_path: Path | None = None,
) -> dict[str, Any]:
    if Groq is None:
        raise RuntimeError("The groq package is required. Install it with: pip install groq")
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError("GROQ_API_KEY is not set. Add it to .env or your environment.")
    if not ontology_path.exists():
        raise FileNotFoundError(f"Ontology RDF file not found: {ontology_path}")

    pdfs = discover_pdfs(folder, recursive)
    if not pdfs:
        raise FileNotFoundError(f"No PDF files were found in {folder}")

    metadata = load_metadata(metadata_path)
    original_graph = Graph()
    original_graph.parse(str(ontology_path))
    # All work is performed on a copy. The source RDF is only replaced after
    # every PDF has completed successfully and --apply was explicitly passed.
    working_graph = deepcopy(original_graph)
    client = Groq(api_key=api_key)
    results: list[dict[str, Any]] = []
    config_registrations: list[tuple[str, str]] = []

    for number, pdf_path in enumerate(pdfs, start=1):
        law_id, law_label = law_metadata(pdf_path, metadata)
        LOGGER.info("[%d/%d] Processing %s (%s)", number, len(pdfs), pdf_path.name, law_id)
        try:
            result = process_regulation_pdf(
                pdf_path=pdf_path,
                graph=working_graph,
                groq_client=client,
                law_id=law_id,
                law_label=law_label,
                model=model,
                apply=True,  # mutate only the in-memory working graph
                min_confidence=min_confidence,
            )
            working_graph = result["updated_graph"]
            results.append({
                "file": str(pdf_path),
                "law_id": law_id,
                "law_label": law_label,
                "status": "processed",
                "requirements_extracted": result["requirements_extracted"],
                "summary": result["summary"],
                "proposals": [_proposal_for_report(p) for p in result["proposals"]],
            })
            config_registrations.append((law_id, law_label))
        except Exception as exc:
            LOGGER.exception("Failed to process %s", pdf_path)
            results.append({
                "file": str(pdf_path),
                "law_id": law_id,
                "law_label": law_label,
                "status": "failed",
                "error": f"{type(exc).__name__}: {exc}",
            })

    summary = summarize_reports(results)
    all_succeeded = summary["pdfs_failed"] == 0
    committed = False

    # Fail closed: do not partially update the ontology if any PDF failed.
    if apply and all_succeeded:
        save_graph_atomic(working_graph, ontology_path, rdf_format="xml")
        committed = True
        if config_path:
            for law_id, law_label in config_registrations:
                register_law_in_config(
                    config_path, law_id, law_label,
                    [law_label, law_id.replace("_", " ")],
                )
    elif apply and not all_succeeded:
        LOGGER.error("At least one PDF failed; no ontology changes were committed.")

    report = {
        "folder": str(folder.resolve()),
        "ontology": str(ontology_path.resolve()),
        "model": model,
        "min_confidence": min_confidence,
        "apply_requested": apply,
        "ontology_committed": committed,
        "all_pdfs_succeeded": all_succeeded,
        "summary": summary,
        "files": results,
        "notes": [
            "A requirement is represented as an individual linked to a reusable control class.",
            "New OWL classes are proposed only for distinct controls or meaningful subclasses.",
            "NEEDS_HUMAN_REVIEW proposals are not inserted into the ontology.",
            "The source ontology is unchanged in dry-run mode.",
            "When --apply is used, the ontology is committed only if every PDF processes successfully.",
        ],
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    LOGGER.info("Batch report written to %s", report_path.resolve())
    return report


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Read every regulation PDF in a folder and agentically classify its requirements against an RDF ontology."
    )
    parser.add_argument("--folder", required=True, help="Folder containing regulation PDFs")
    parser.add_argument("--ontology", required=True, help="Existing RDF/OWL ontology file")
    parser.add_argument("--recursive", action="store_true", help="Also scan subfolders")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"Groq model (default: {DEFAULT_MODEL})")
    parser.add_argument("--min-confidence", type=float, default=0.72,
                        help="Minimum heuristic confidence required for automatic validation")
    parser.add_argument("--metadata", help="Optional JSON mapping filenames to law IDs and full labels")
    parser.add_argument("--report", default="agentic_regulation_folder_report.json",
                        help="JSON report output path")
    parser.add_argument("--config", help="Optional config.json to register laws after successful commit")
    parser.add_argument("--apply", action="store_true",
                        help="Commit validated changes; without this flag the run is a dry run")
    args = parser.parse_args()

    try:
        report = run_batch(
            folder=Path(args.folder),
            ontology_path=Path(args.ontology),
            recursive=args.recursive,
            apply=args.apply,
            model=args.model,
            min_confidence=args.min_confidence,
            report_path=Path(args.report),
            metadata_path=Path(args.metadata) if args.metadata else None,
            config_path=Path(args.config) if args.config else None,
        )
    except Exception as exc:
        LOGGER.error("Batch run could not start: %s", exc)
        return 2

    print(json.dumps({
        "summary": report["summary"],
        "ontology_committed": report["ontology_committed"],
        "report": str(Path(args.report).resolve()),
    }, indent=2))
    if report["summary"]["pdfs_failed"]:
        return 1
    if not args.apply:
        print("DRY RUN: no changes were written to the source ontology. Review the JSON report before using --apply.")
    elif not report["ontology_committed"]:
        print("No changes committed because at least one PDF failed.")
        return 1
    return 0


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    sys.exit(main())
